**{
  "language": "en",
  "summary": "This document is a Continuing Reimbursement Agreement for Letters of Credit between U.S. Bank National Association and MI Homes, Inc., dated July 27, 2009. It outlines the authorization for specific individuals to give instructions and execute applications related to letters of credit issued by the bank for the applicant. The document also details the conditions under which discrepancies in documents presented under a credit can be waived and the bank's authority to deduct amounts due from the applicant's accounts.",
  "authors": [
    "Philip G. Creek",
    "Ann Marie Hunker",
    "William Roberts",
    "Kevin Hake"
  ],
  "extracted_text": "SCHEDULE 1 AUTHORIZATION CONTINUING REIMBURSEMENT AGREEMENT FOR LETTERS OF CREDIT The provisions of this Schedule 1 are hereby incorporated into and made a part of the Continuing Reimbursement Agreement for Letters of Credit (\"Agreement\") executed by and between U.S. BANK NATIONAL ASSOCIATION, (\"Bank\") and MI HOMES, INC. (\"Applicant\"), dated July 27, 2009. Capitalized terms not otherwise defined herein shall have the meanings assigned to them in the Agreement. 1. In addition to those authorized through U.S. Bank Global Trade Works or other electronic letter of credit application system offered by Bank, if applicable, any one of the persons whose name, title and signature appears below is authorized to give instructions to Bank and to execute and/or transmit Applications, requests for amendments, requests for extensions and other communications of any nature regarding any Credit issued by Bank for Applicant. NAME TITLE SIGNATURE Philip G. Creek Exec VP & CFO Ann Marie Hunker Corp Controller & CAO William Roberts VP, Treasurer Kevin Hake VP, Finance 2. In addition to those authorized through U.S. Bank Global Trade Works or other electronic letter of credit application system offered by Bank, if applicable, the following persons are entitled to waive discrepancies contained in documents presented under a Credit. (Applicant understands that upon any such waiver, Applicant is obligated to reimburse Bank to the same extent as if the documents fully complied with the terms of the Credit.): NAME TITLE TELEPHONE NUMBER Philip G. Creek Exec VP & CFO 614-468-8000 Ann Marie Hunker Corp Controller & CAO William Roberts VP, Treasurer 614-468-8227 Kevin Hake VP, Finance 3. Bank is instructed to automatically deduct from Account No. _____ all amounts which become due under the Agreement. Should there be insufficient funds in this account to reimburse Bank, Bank is authorized to deduct any remaining amounts due from any of Applicant's accounts with Bank. 4. This Schedule 1 shall be effective upon receipt by Bank. Bank may rely on this Schedule I until it has been revoked in writing by Applicant and Bank has a reasonable opportunity to act on any such revocation. APPLICANT: MI HOMES, INC. By: Name: Philip G. Creek Title: Exec VP & CFO Date: BANK: U.S. BANK NATIONAL ASSOCIATION By: Name: Title: Date: Philip G. Creek Exec VP, CFO 2-1-10"
}**

# AUTHORIZATION
## CONTINUING REIMBURSEMENT AGREEMENT FOR LETTERS OF CREDIT

The provisions of this Schedule 1 are hereby incorporated into and made a part of the Continuing Reimbursement Agreement for Letters of Credit ("Agreement") executed by and between **U.S. BANK NATIONAL ASSOCIATION, ("Bank")** and **M/I HOMES, INC. ("Applicant")**, dated July 27, 2009. Capitalized terms not otherwise defined herein shall have the meanings assigned to them in the Agreement.

1. In addition to those authorized through **U.S. Bank Global Trade Works** or other electronic letter of credit application system offered by Bank, if applicable, any one of the persons whose name, title and signature appears below is authorized to give instructions to Bank and to execute and/or transmit Applications, requests for amendments, requests for extensions and other communications of any nature regarding any Credit issued by Bank for Applicant.

   - **NAME**: __________________________
   - **Pillip G. Creek**: 
   - **Ann Marie Harker**: 
   - **William H. Roberts**: 
   - **Kevin Hake**: 

2. In addition to those authorized through **U.S. Bank Global Trade Works** or other electronic letter of credit application system offered by Bank, if applicable, the following persons are entitled to waive discrepancies contained in documents presented under a Credit. (Applicant understands that upon any such waiver, Applicant is obligated to reimburse Bank to the same extent as if the documents fully complied with the terms of the Credit.):

   - **NAME**: __________________________
   - **Pillip G. Creek**: 
   - **Ann Marie Harker**: 
   - **William H. Roberts**: 

3. Bank is instructed to automatically deduct from Account No. _______ all amounts which become due under the Agreement. Should there be insufficient funds in this account to reimburse Bank, Bank is authorized to deduct any remaining amounts due from any of Applicant's accounts with Bank.

4. This Schedule 1 shall be effective upon receipt by Bank. Bank may rely on this Schedule 1 until it has been revoked in writing by Applicant and Bank has a reasonable opportunity to act on any such revocation.

   - **APPLICANT**: __________________________
   - **M/I HOMES, INC.**: __________________________
   - **BANK**: __________________________
   - **U.S. BANK NATIONAL ASSOCIATION**: __________________________
   - **By**: __________________________
   - **Name**: _Pillip G. Creek
   - **Title**: _Exec V P + CFO
   - **Date**: __________________________
   - **By**: __________________________
   - **Name**: __________________________
   - **Title**: _Date: __________________________
   - **Date**: __________________________

   - **Pillip G. Creek**: __________________________
   - **EVP**: _CFO
   - **2-1-10**: __________________________

Continuing Reimbursement Agreement

rev. 12/04
**{
  "language": "en",
  "summary": "This document is a legal agreement between JPMorgan Chase Bank, N.A. and the City of Lake Worth Beach. It outlines that the Account Terms are executed by authorized officers from both parties and are legally binding and effective upon execution by both the Customer and the Bank.",
  "authors": [
    "JPMorgan Chase Bank, N.A.",
    "City of Lake Worth Beach"
  ],
  "extracted_text": "IN WITNESS WHEREOF, the parties hereto have caused these Account Terms to be executed by their respective authorized officers. These Account Terms shall be legally binding and deemed effective upon the date when the Account Terms have been executed by both the Customer and the Bank. JPMORGAN CHASE BANK, N.A. Signature: _____________________________ Print Name: HUASCAR R. HILDEVERT Title: AUTHORIZED OFFICER Date: 9/24/21 City of Lake Worth Beach Signature: _____________________________ Print Name: _____________________________ Title: _____________________________ Date: _____________________________"
}**

IN WITNESS WHEREOF, the parties hereto have caused these Account Terms to be executed by their respective authorized officers. These Account Terms shall be legally binding and deemed effective upon the date when the Account Terms have been executed by both the Customer and the Bank.

JPMORGAN CHASE BANK, N.A.

Signature: 4ths6vzt

Print Name: HUASCAR R. HILDEVERT

Title: AUTHORIZED OFFICER

Date: 9/24/21

City of Lake Worth Beach

Signature: ______________________________

Print Name: ______________________________

Title: ______________________________

Date: ______________________________
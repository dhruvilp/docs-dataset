**{
  "language": "en",
  "summary": "This document is a lease agreement for a 2023 Chrysler Pacifica van. The lease details include the vehicle specifications, payment schedule, and various financial disclosures required by the Federal Consumer Leasing Act. Key points include the amount due at lease signing, monthly payments, total payments over the lease term, and additional charges. The lease also outlines conditions for early termination, excessive wear and use, and the purchase option at the end of the lease term.",
  "authors": ["Lessor (unnamed)", "Assignee (Ally Financial)"],
  "extracted_text": "We, \"us,\" and \"our\" refer to Lessor named above and any assignee. An \"assignee\" is a person to whom this lease is assigned (if it is assigned). If this box is checked, Lessor will assign this lease and sell the vehicle to: ALLY FINANCIAL (Assignee). If this box is checked, Lessor intends not to assign this lease. Monthly Payment Lease. If your payment schedule shows monthly scheduled payments (Section 2(a)), your lease is a monthly payment lease. Single Payment Lease. If your payment schedule shows a single scheduled payment (Section 2(b)), your lease is a single payment lease. The Vehicle You Are Leasing New/Used Year Make & Model Body Style Vehicle ID # Mileage Primary Use: Personal, unless otherwise indicated below Commercial, Business, or Agricultural Public Conveyance NEW 2023 CHRYSLER PACIFICA VAN 10 Federal Consumer Leasing Act Disclosures 1. Amount Due at Lease Signing or Delivery (Itemized Below)* 2(a). Monthly Scheduled Payments Your first monthly payment of $ 570.83 is due on 09/09/2024 followed by 34 payment(s) of $ 570.83, then 1 payment(s) of $ 570.83, and then 1 payment(s) of $ 570.83, due on the 9th of each month. The total of your monthly payments is 20549.88 2(b). Single Scheduled Payment Your single payment of $ N/A is due on N/A. This is the total of your scheduled payments. 3. Other Charges (not part of your scheduled payment) Disposition fee (if you do not purchase the vehicle and we do not waive the fee under Section 14) $ 395.00 N/A $ N/A Total $ 395.00 4. Total of Payments (The amount you will have paid by the end of the lease.) $ 32900.11 5. Amount Due at Lease Signing or Delivery: a. Capitalized cost reduction $ 9780.96 b. First monthly payment $ 570.83 c. Single scheduled payment $ N/A d. Refundable security deposit $ 950.00 e. Title fee $ N/A f. Registration fee $ 1024.27 g. Sales/use tax $ N/A h. N/A $ N/A i. DOC FEE $ 200.00 j. N/A $ N/A k. Total $ 12526.06 6. How the Amount Due at Lease Signing or Delivery will be paid: a. Net trade-in allowance. $ 7500.00 b. Rebates and noncash credits $ 5000.00 c. Amount to be paid in cash $ 5000.00 d. Total $ 12526.06 7. Your scheduled payment is determined as shown below: a. Gross capitalized cost. The agreed upon value of the vehicle ($ 43935.00) and any items you pay for over the lease term (such as service contracts, insurance, and any outstanding prior credit or lease balance). $ 44630.00 b. Capitalized cost reduction. The amount of any net trade-in allowance, rebate, noncash credit, or cash you pay that reduces the gross capitalized cost $ 9780.96 c. Adjusted capitalized cost. The amount used in calculating your base scheduled payment $ 34849.04 d. Residual value. The value of the vehicle at the end of the lease $ 26222.70 e. Depreciation and any amortized amounts. The amount charged for the vehicle's decline in value through normal use and for other items paid over the lease term. $ 8626.34 f. Rent charge in addition to the depreciation and any amortized amounts $ 11923.54 g. Total of base scheduled payment(s). The depreciation and any amortized amounts plus the rent charge $ 20549.88 h. Lease payments. The number of payments in your lease 36 i. Base scheduled payment $ 570.83 j. Sales/use tax (estimated) First 34 payment(s) $ N/A Next 1 payment(s) $ N/A Last 1 payment(s) $ N/A k. N/A $ 59.94 l. Total scheduled payment First 34 payment(s) $ 570.83 Next 1 payment(s) $ 570.83 Last 1 payment(s) $ 570.83 Early Termination. You may have to pay a substantial charge if you end this lease early. The charge may be up to several thousand dollars. The actual charge will depend on when the lease is terminated. The earlier you end the lease the greater this charge is likely to be. 8. Excessive Wear and Use. You may be charged for excessive wear based on our standards for normal use and for mileage in excess of 10,000 miles per year at the rate of $ 0.20 per mile. 9. Purchase Option at End of Lease Term. You have an option to buy the vehicle at the end of the lease term for $ 26222.70 plus official fees and taxes. 10. Other Important Terms. See your lease documents for additional information on early termination, purchase options and maintenance responsibilities, warranties, late and default charges, and insurance."
}**

"We," "us," and "our" refer to Lessor named above and any assignee. An "assignee" is a person to whom this lease is assigned (if it is assigned).
If this box is checked, Lessor will assign this lease and sell the vehicle to **ALLY FINANCIAL** (Assignee).
☐ If this box is checked, Lessor intends not to assign this lease.
Monthly Payment Lease. If your payment schedule shows monthly scheduled payments (Section 2(a)), your lease is a monthly payment lease.
Single Payment Lease. If your payment schedule shows a single scheduled payment (Section 2(b)), your lease is a single payment lease.

The Vehicle You Are Leasing
New/Used Year Make & Model Body Style Vehicle ID # Mileage Primary Use: Personal, unless otherwise
☐ New 2023 CHRYSLER PACIFICA VAN ☐ New ☐
Dealer Installed Options N/A (if truck) N/A ☐ Public Conveyance

Federal Consumer Leasing Act Disclosures
1. Amount Due at 2(a). Monthly Scheduled Payments 3. Other Charges (not part of your scheduled payment) 4. Total of Payments
Lease Signing Your first monthly payment of $ 570.83 3. Disposition fee (if you do
or Delivery is due on 09/09/2024 followed by 34 not purchase the vehicle 5. 395.00
payment(s) of $ 570.83, then 1 fee under Section 14) $ 395.00
payment(s) of $ 570.83, and then N/A $ N/A
1. ☐ 12526.06 payment(s) of $ 570.83, due
on the 9th of each month. The total of
your monthly payments is 20549.88
2(b). Single Scheduled Payment
Your single payment of $ N/A is due
on N/A. This is the total
of your scheduled payments. Total $ 395.00 $ 32900.11

* Itemization of Amount Due at Lease Signing or Delivery
5. Amount Due at Lease Signing or Delivery:
a. Capitalized cost reduction $ 9780.96
b. First monthly payment $ 570.83
c. Single scheduled payment N/A
d. Refundable security deposit $ N/A
e. Title fees $ 950.00
f. Registration fees N/A
g. Sales/use tax. $ 1024.27
h. N/A N/A
i. DOC FEE $ 200.00
j. N/A $ N/A
k. Total $ 12526.06 d. Total $ 12526.06

7. Your scheduled payment is determined as shown below:
a. Gross capitalized cost. The agreed upon value of the vehicle ($ 43935.00) and any items you pay for over the
lease term (such as service contracts, insurance, and any outstanding prior credit or lease balance) $ 44630.00
b. Capitalized cost reduction. The amount of any net trade-in allowance, rebate, noncash credit, or cash you pay that
reduces the gross capitalized cost $ 9780.96
c. Adjusted capitalized cost. The amount used in calculating your base scheduled payment $ 34849.04
d. Residual value. The value of the vehicle at the end of the lease used in calculating your base scheduled payment $ 26222.70
e. Depreciation and any amortized amounts. The amount charged for the vehicle's decline in value through normal use
and for other items paid over the lease term $ 8626.34
f. Rent charge. The amount charged in addition to the depreciation and any amortized amounts $ 11923.54
g. Total of base scheduled payment(s). The depreciation and any amortized amounts plus the rent charge $ 20549.88
h. Lease payments. The number of payments in your lease $ 96
i. Base scheduled payment $ 570.83
j. Sales/use tax (estimated) First 34 payment(s) $ 570.83
Next 1 payment(s) $ +$ N/A
Last 1 payment(s) $ +$ $ 59.94
k. N/A
1. Total scheduled payment First 34 payment(s) $ 570.83
Next 1 payment(s) $ =$ $ 570.83
Last 1 payment(s) $ =$ $ 570.83

Early Termination. You may have to pay a substantial charge if you end this lease early. The charge may be up to several thousand dollars.
The actual charge will depend on when the lease is terminated. The earlier you end the lease, the greater this charge is likely to be.
8. Excessive Wear and Use. You may be charged for excessive wear based on our standards for normal use and for mileage in excess of 10,000
miles per year at the rate of $ 20 per mile.
9. Purchase Option at End of Lease Term. You have an option to buy the vehicle at the end of the lease term for $ 26222.70
plus official fees and taxes.
10. Other Important Terms. See your lease documents for additional information on early termination, purchase options and maintenance responsibilities,
warranties, late and default charges, and insurance.
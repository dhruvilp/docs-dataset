**{
  "language": "en",
  "summary": "This document is an Account Opening Memorandum (AOM) for a new bank account. It includes details such as the customer's name, account type, initial payment details, and various declarations confirming compliance with KYC (Know Your Customer) and AML (Anti-Money Laundering) policies. The document also includes signatures from the branch official and the customer, verifying the accuracy and completeness of the information provided.",
  "authors": [
    "Bank Official",
    "Customer"
  ],
  "extracted_text": "ACCOUNT OPENING MEMORANDUM SOL Customer Name Branch Existing Client? Yes No Existing Client ID Existing UCIC? Yes No Existing UCIC ID 14 digit CKYC A/c Opening by Normal Preferred Royal Speed gate Express Welcome Id Initial Payment Details Credited to Account No 3720010 Value Date Finacle Tran ID Details of Label Codes (In case of Other Label code, please specify the nature) DST Pay Roll Other Other Other Details Scheme Code GL Sub Head Code Vertical Date of Desp. of AOF to RPU K S I C A 6 K 4 We submit the Account Opening form (AOF) with the above details and request you to open the account. We confirm that: i. The Account Opening form (AOF) is complete in all respect for opening an account. ii. A Branch Official had sighted the original of all the documents provided for opening the account. iii. We have complied with all the requirement of the KYC and AML Policy, KYC & AML Master Circular of the Bank up dated till now. iv. We have complied with all requirement circular / instructions issued by the Bank till date with regard to the proposed Product. v. We have verified the updated Caution / Black List of UN / GOI for the name of the applicant/s and confirm that the name does not exist in any Caution / Black List. vi. We confirm that by opening this account, the individual/non individual applicant would not have a second client ID in the Bank. (OIR) Customer is an existing non individual customer of bank, for account operating convenience; a new customer id has to be generated for the customer. The existing Uniform Customer Identification Code (UCIC) of the customer number has been captured on AOF for linking new customer id with existing UCIC. vii. All Statutory, Regulatory and Internal guidelines issued up-to-date have been complied with regard to the AOF. viii. Tele-verification a applicable /not applicable to the said client as per extant KYC guidelines of the Bank. If applicable, declaration is provided below. Declaration for Televerification, if applicable I hereby confirm that I have conducted Tele-Verification of the said prospective client of Mobile Phone Number. The Tele-Verification was conducted on 13/10/2022 Signature of the approving RN and Stamp Declaration by Branch Head I hereby certify that all necessary KYC documents have been obtained and verified by me. I confirm that the documents are adequate to comply with KYC requirements of the Bank. Based on this, the account maybe opened Signature of the approving RN and Stamp"
}**

# ACCOUNT OPENING MEMORANDUM

|  SOI | Branch | ARQUAH  |
| --- | --- | --- |
|  Customer Name | ANJAN BHUSHAN |   |
|  Existing Client? | Yes | No Existing Client ID  |
|  Existing UCIC? | Yes | No Existing UCIC ID  |
|  14 digit CKYC |  |   |
|  A/c Opening by | Normal | Preferred  |
|  Initial Payment Details |  |   |
|  Credited to Account No | Value Date | Finacle Tran ID  |
|  37200010 | 0 | 00 M M Y Y  |
|  Details of Label Codes (In case of Other Label code, Please specify the nature) |  |   |
|  DST | Pay Roll | Other  |
|  57F346694 |  |   |
|  Other Details |  |   |
|  Scheme Code | GL Sub Head Code | Vertical  |
|  KSCAQ |  | KBL  |

We submit the Account Opening form (AOF) with the above details and request you to open the account. We confirm that:

i. The Account Opening form (AOF) is complete in all respects for opening an account. ii. A Branch Official had signed the original of all the documents provided for opening the account. iii. We have complied with all the requirements of the KYC and AML Policy, KYC & AML Master Circular of the Bank, up dated 11/11/2014. iv. We have complied with all requirements circulars / instructions issued by the Bank to date with regard to the proposed Product. v. We have verified the updated Caution / Black Lists of UN / GOI for the name of the applicant/s and confirm that the name does not exist in any Caution / Black List vi. We confirm that by opening this account, the individual/non-individual applicant would not have a second client ID in the Bank. (OR) vii. Customer is an existing non-individual customer of bank, for account operating convenience: a new customer id has to be generated for the customer. The existing Uniform Customer Identification Code (UCIC) of the customer number has been captured on AOF for linking new customer id with existing UCIC. viii. All Statutory, Regulatory and Internal guidelines issued up-to-date have been complied with regard to this AOF. viiii. Tele-verification is applicable /not applicable to the said client as per extant KYC guidelines of the Bank. If applicable, declaration is provided below.

Signature of SOM (EIN and Stamp)

|  Declaration for Televerification, if applicable | Declaration by Branch Head  |
| --- | --- |
|  I hereby confirm that I have conducted Tele-Verification of the said prospective client at Mobile Phone Number. The Tele-Verification was conducted on 12/10/2014. | I hereby certify that all necessary KYC documents have been obtained and verified by me. I confirm that the documents are adequate to comply with KYC requirements of the Bank. Based on this, the account may be opened.  |
|  Signature of the sole person (EIN and Stamp) | Signature of the bank (EIN and Stamp)  |
|  37200010 | 37200010  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  Signature of the 11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |
|  11/11/2014 11:22 | 11/11/2014  |

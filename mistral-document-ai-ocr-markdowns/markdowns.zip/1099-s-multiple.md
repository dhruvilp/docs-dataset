**{
  "language": "en",
  "summary": "This document is a set of IRS Form 1099-S, which reports proceeds from real estate transactions. It includes details such as the date of closing, gross proceeds, and the addresses of the properties involved. The forms are filled out by ABC Company, LLC, and list multiple real estate transactions in Beverly Hills, CA.",
  "authors": ["Internal Revenue Service"],
  "extracted_text": "Form 1099-S\n\n1. Date of closing: 5-1-16\n2. Gross proceeds: $4,000.00\n3. Address or legal description (including city, state, and ZIP code): Rope 62 Section 78, Block 54, Lot 8, City of Beverly Hills, California 90210\n\n1. Date of closing: 5-1-16\n2. Gross proceeds: $3,000.00\n3. Address or legal description (including city, state, and ZIP code): 452 Lewis St NE, Beverly Hills, CA 90210\n\n1. Date of closing: 5-1-16\n2. Gross proceeds: $2,000.00\n3. Address or legal description (including city, state, and ZIP code): 805 Oakwood Ln, Beverly Hills, CA 90210"
}**

# 7575 ☐ VOID ☐ CORRECTED

|  |   |   |   |
| --- | --- | --- | --- |
|  **FLER'S name, street address, city or town, state or province, country, ZIP or foreign postal code, and telephone number** | 1 | **Date of closing** | **CMS No. 1545-0997**  |
|  **AISC Company, LLC** |  | 5-1-16 |   |
|  4567 Sunee, State St., Ste 123 |  | 2016 | Proceeds From Real Estate Transactions  |
|  Grand Rapids, MI 49525 |  |  |   |
|  987-634-3210 |  | 4,000.00 | Form 1099-S  |
|  **FLER'S federal identification number** |  | **Address or legal description (including city, state, and ZIP code)** | **Copy A**  |
|  12-3456789 |  |  | For Internal Revenue Service Center File with Form 1096. For Privacy Act and Paperwork Reduction Act Notice, see the 2016 General Instructions for Certain Information  |
|  **TRANSFEROR'S name** |  |  |   |
|  **AISC Company, LLC** |  |  |   |
|  Street address (including apt. no.) |  |  |   |
|  4567 Sunee, State St., Ste 123 |  | 4 Check here if the transferor received or will receive property or services as part of the consideration ▶ |   |
|  City or town, state or province, country, and ZIP or foreign postal code |  |  |   |
|  Grand Rapids, MI 49525 |  | 5 Buyer's part of real estate tax |   |
|  Account or second number (see instructions) |  |  |   |
|  **N/A** |  |  |   |
|  **Form 1099-S** |  | **Cat. No. 64292E** | **www.irs.gov/form1099e**  |
|  Do Not Cut or Separate Forms on This Page - Do Not Cut or Separate Forms on This Page |  |  |   |

# 7575 ☐ VOID ☐ CORRECTED

|  |   |   |   |
| --- | --- | --- | --- |
|  **FLER'S name, street address, city or town, state or province, country, ZIP or foreign postal code, and telephone number** | 1 | **Date of closing** | **CMS No. 1545-0997**  |
|  **AISC Company, LLC** |  | 5-1-16 |   |
|  4567 Sunee, State St., Ste 123 |  | 2016 | Proceeds From Real Estate Transactions  |
|  Grand Rapids, MI 49525 |  |  |   |
|  987-634-3210 |  | 4,000.00 | Form 1099-S  |
|  **FLER'S federal identification number** |  | **Address or legal description (including city, state, and ZIP code)** | **Copy A**  |
|  12-3456789 |  |  | For Internal Revenue Service Center File with Form 1096. For Privacy Act and Paperwork Reduction Act Notice, see the 2016 General Instructions for Certain Information  |
|  **TRANSFEROR'S name** |  |  |   |
|  **AISC Company, LLC** |  |  |   |
|  Street address (including apt. no.) |  |  |   |
|  4567 Sunee, State St., Ste 123 |  | 4 Check here if the transferor received or will receive property or services as part of the consideration ▶ |   |
|  City or town, state or province, country, and ZIP or foreign postal code |  |  |   |
|  Grand Rapids, MI 49525 |  | 5 Buyer's part of real estate tax |   |
|  Account or second number (see instructions) |  |  |   |
|  **N/A** |  |  |   |
|  **Form 1099-S** |  | **Cat. No. 64292E** | **www.irs.gov/form1099e**  |
|  Do Not Cut or Separate Forms on This Page - Do Not Cut or Separate Forms on This Page |  |  |   |

# 7575 ☐ VOID ☐ CORRECTED

|  |   |   |   |
| --- | --- | --- | --- |
|  **FLER'S name, street address, city or town, state or province, country, ZIP or foreign postal code, and telephone number** | 1 | **Date of closing** | **CMS No. 1545-0997**  |
|  **AISC Company, LLC** |  | 5-1-16 |   |
|  4567 Sunee, State St., Ste 123 |  | 2016 | Proceeds From Real Estate Transactions  |
|  Grand Rapids, MI 49525 |  |  |   |
|  987-634-3210 |  | 4,000.00 | Form 1099-S  |
|  **FLER'S federal identification number** |  | **Address or legal description (including city, state, and ZIP code)** | **Copy A**  |
|  12-3456789 |  |  | For Internal Revenue Service Center File with Form 1096. For Privacy Act and Paperwork Reduction Act Notice, see the 2016 General Instructions for Certain Information  |
|  **TRANSFEROR'S name** |  |  |   |
|  **AISC Company, LLC** |  |  |   |
|  Street address (including apt. no.) |  |  |   |
|  4567 Sunee, State St., Ste 123 |  | 4 Check here if the transferor received or will receive property or services as part of the consideration ▶ |   |
|  City or town, state or province, country, and ZIP or foreign postal code |  |  |   |
|  Grand Rapids, MI 49525 |  | 5 Buyer's part of real estate tax |   |
|  Account or second number (see instructions) |  |  |   |
|  **N/A** |  |  |   |
|  **Form 1099-S** |  | **Cat. No. 64292E** | **www.irs.gov/form1099e**  |
|  Do Not Cut or Separate Forms on This Page - Do Not Cut or Separate Forms on This Page |  |  |   |
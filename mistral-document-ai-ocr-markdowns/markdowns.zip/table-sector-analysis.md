**{
  "language": "en",
  "summary": "The document presents a sector analysis for the 2015 KICK Start Energy Ginetta Junior Championship, Round 12. It details the performance of four drivers (Billy Monger, Senna Proctor, Dan Zelos, and William Tregurtha) across three sectors of the track, including their lap times, speeds, and differences to their personal best laps. Each driver's best lap time and the corresponding sector times are highlighted.",
  "authors": ["2015 KICK Start Energy Ginetta Junior Championship"],
  "extracted_text": "2015 KICK Start Energy Ginetta Junior Championship ROUND 12 - SECTOR ANALYSIS SECTOR 1 = FL to I1, SECTOR 2 = I1 to I2, SECTOR 3 = I2 to FL, DIFF = Difference To Personal Best Lap P1 23 Billy MONGER JHR Developments IDEAL LAP TIME : 2:21.010 BEST LAP TIME : 2:21.010 DIFFERENCE : 0.000 LAP SECTOR 1 SECTOR 2 SECTOR 3 LAP TIME MPH DIFF TIME OF DAY 1 - 93.7 50.271 105.8 46.471 93.4 2:29.100 71.68 8.090 13:56:25.654 2 - 44.690 94.2 50.566 106.1 46.697 93.0 2:21.953 75.29 0.943 13:58:47.607 3 - 44.656 94.3 50.332 106.8 46.461 93.2 2:21.449 (3) 75.56 0.439 14:01:09.056 4 - 44.483 94.1 50.225 106.1 46.302 93.9 2:21.010 (1) 75.79 0.000 14:03:30.066 5 - 44.499 94.5 50.314 106.1 46.522 93.8 2:21.335 (2) 75.62 0.325 14:05:51.401 6 - 44.882 93.9 50.683 106.1 47.106 93.5 2:22.671 74.91 1.661 14:08:14.072 P2 66 Senna PROCTOR JHR Developments IDEAL LAP TIME : 2:21.449 BEST LAP TIME : 2:21.623 DIFFERENCE : 0.174 LAP SECTOR 1 SECTOR 2 SECTOR 3 LAP TIME MPH DIFF TIME OF DAY 1 - 93.7 50.559 106.0 46.592 93.9 2:30.893 70.83 9.270 13:56:27.447 2 - 44.688 94.1 50.350 107.0 46.762 94.9 2:21.800 (2) 75.37 0.177 13:58:49.247 3 - 44.630 94.3 50.469 107.3 46.524 93.5 2:21.623 (1) 75.46 0.000 14:01:10.870 4 - 44.579 94.2 51.486 106.8 47.521 96.0 2:23.586 74.43 1.963 14:03:34.456 5 - 45.336 93.4 50.651 106.5 46.520 95.4 2:22.507 75.00 0.884 14:05:56.963 6 - 44.817 93.2 50.779 107.7 46.604 93.3 2:22.200 (3) 75.16 0.577 14:08:19.163 P3 45 Dan ZELOS JHR Developments IDEAL LAP TIME : 2:20.706 BEST LAP TIME : 2:20.708 DIFFERENCE : 0.002 LAP SECTOR 1 SECTOR 2 SECTOR 3 LAP TIME MPH DIFF TIME OF DAY 1 - 90.6 51.311 106.5 47.470 93.7 2:34.565 69.14 13.857 13:56:31.119 2 - 44.674 94.3 50.455 106.5 46.406 94.2 2:21.535 (3) 75.51 0.827 13:58:52.654 3 - 44.447 94.6 50.272 107.8 46.391 94.7 2:21.110 (2) 75.74 0.402 14:01:13.764 4 - 44.259 95.1 50.056 108.0 46.393 96.1 2:20.708 (1) 75.95 0.000 14:03:34.472 5 - 45.447 93.8 50.632 107.0 46.523 94.9 2:22.602 74.95 1.894 14:05:57.074 6 - 44.860 93.7 50.734 107.0 46.803 94.7 2:22.397 75.05 1.689 14:08:19.471 P4 71 William TREGURTHA (R) RCE IDEAL LAP TIME : 2:21.376 BEST LAP TIME : 2:22.974 DIFFERENCE : 1.608"
}**

# 2015 KICK Start Energy Ginetta Junior Championship

## ROUND 12 - SECTOR ANALYSIS

SECTOR 1 = FL to I1, SECTOR 2 = I1 to I2, SECTOR 3 = I2 to FL, DIFF = Difference To Personal Best Lap

|  P1 | 23 | Billy MONGER |  |  | JHR Developments |  |  |  |  |   |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  IDEAL LAP TIME : 2:21.010 |  |  | BEST LAP TIME : 2:21.010 |  | DIFFERENCE : 0.000 |  |  |  |  |   |
|  LAP | SECTOR 1 |  | SECTOR 2 |  | SECTOR 3 |  | LAP TIME | MPH | DIFF | TIME OF DAY  |
|  1 - |  | 93.7 | 50.271 | 105.8 | 46.471 | 93.4 | 2:29.100 | 71.68 | 8.090 | 13:56:25.654  |
|  2 - | 44.690 | 94.2 | 50.566 | 106.1 | 46.697 | 93.0 | 2:21.953 | 75.29 | 0.943 | 13:58:47.607  |
|  3 - | 44.656 | 94.3 | 50.332 | 106.8 | 46.461 | 93.2 | 2:21.449 | (3) | 75.56 | 0.439  |
|  4 - | 44.483 | 94.1 | 50.225 | 106.1 | 46.302 | 93.9 | 2:21.010 | (1) | 75.79 |   |
|  5 - | 44.499 | 94.5 | 50.314 | 106.1 | 46.522 | 93.8 | 2:21.335 | (2) | 75.62 | 0.325  |
|  6 - | 44.882 | 93.9 | 50.683 | 106.1 | 47.106 | 93.5 | 2:22.671 | 74.91 | 1.661 | 14:08:14.072  |

|  P2 | 66 | Senna PROCTOR |  |  | JHR Developments |  |  |  |  |   |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  IDEAL LAP TIME : 2:21.449 |  |  | BEST LAP TIME : 2:21.623 |  | DIFFERENCE : 0.174 |  |  |  |  |   |
|  LAP | SECTOR 1 |  | SECTOR 2 |  | SECTOR 3 |  | LAP TIME | MPH | DIFF | TIME OF DAY  |
|  1 - |  | 93.7 | 50.559 | 106.0 | 46.592 | 93.9 | 2:30.893 | 70.83 | 9.270 | 13:56:27.447  |
|  2 - | 44.688 | 94.1 | 50.350 | 107.0 | 46.762 | 94.9 | 2:21.800 | (2) | 75.37 | 0.177  |
|  3 - | 44.630 | 94.3 | 50.469 | 107.3 | 46.524 | 93.5 | 2:21.623 | (1) | 75.46 |   |
|  4 - | 44.579 | 94.2 | 51.486 | 106.8 | 47.521 | 96.0 | 2:23.586 | 74.43 | 1.963 | 14:03:34.456  |
|  5 - | 45.336 | 93.4 | 50.651 | 106.5 | 46.520 | 95.4 | 2:22.507 | 75.00 | 0.884 | 14:05:56.963  |
|  6 - | 44.817 | 93.2 | 50.779 | 107.7 | 46.604 | 93.3 | 2:22.200 | (3) | 75.16 | 0.577  |
|  P3 | 45 | Dan ZELOS |  |  | JHR Developments |  |  |  |  |   |
|  IDEAL LAP TIME : 2:20.706 |  |  | BEST LAP TIME : 2:20.708 |  | DIFFERENCE : 0.002 |  |  |  |  |   |
|  LAP | SECTOR 1 |  | SECTOR 2 |  | SECTOR 3 |  | LAP TIME | MPH | DIFF | TIME OF DAY  |
|  1 - |  | 90.6 | 51.311 | 106.5 | 47.470 | 93.7 | 2:34.565 | 69.14 | 13.857 | 13:56:31.119  |
|  2 - | 44.674 | 94.3 | 50.455 | 106.5 | 46.406 | 94.2 | 2:21.535 | (3) | 75.51 | 0.827  |
|  3 - | 44.447 | 94.6 | 50.272 | 107.8 | 46.391 | 94.7 | 2:21.110 | (2) | 75.74 | 0.402  |
|  4 - | 44.259 | 95.1 | 50.056 | 108.0 | 46.393 | 96.1 | 2:20.708 | (1) | 75.95 |   |
|  5 - | 45.447 | 93.8 | 50.632 | 107.0 | 46.523 | 94.9 | 2:22.602 | 74.95 | 1.894 | 14:05:57.074  |
|  6 - | 44.860 | 93.7 | 50.734 | 107.0 | 46.803 | 94.7 | 2:22.397 | 75.05 | 1.689 | 14:08:19.471  |
|  P4 | 71 | William TREGURTHA (R) |  |  | RCE |  |  |  |  |   |
|  IDEAL LAP TIME : 2:21.276 |  |  | BEST LAP TIME : 2:22.274 |  | DIFFERENCE : 0.000 |  |  |  |  |   |
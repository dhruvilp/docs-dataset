**{
  "language": "en",
  "summary": "This document is a 'Request for Verification of Employment' form. It includes sections for the lender, employer, and applicant to provide information about the applicant's employment status and history. The form is used to verify employment details for mortgage loan applications.",
  "authors": [
    "Alejandro Rosalez",
    "Carlos Salazar",
    "Paulo Santos",
    "Richard Roe"
  ],
  "extracted_text": "Request for Verification of Employment  Privacy Act Notice: This information is to be used by the agency collecting it or its assignees in determining whether you qualify as a prospective mortgagor under its program. It will not be disclosed outside the agency except as required and permitted by law. You do not have to provide this information, but if you do not your application for approval as a prospective mortgagor or borrower may be delayed or rejected. The information requested in this form is authorized by Title 38, USC, Chapter 37 (if VAI); by 12 USC, Section 1701 et. seq. (if HUD/FHA); by 42 USC, Section 1452b (if HUD/CPD); and Title 42 USC, 1471 et. seq., or 7 USC, 1921 et. seq. (if USDA/FmHA).  Instructions: Lender - Complete items 1 through 7. Have applicant complete item 8. Forward directly to employer named in item 1. Employer - Please complete either Part II or Part III as applicable. Complete Part IV and return directly to lender named in item 2. The form is to be transmitted directly to the lender and is not to be transmitted through the applicant or any other party.  Part I - Request  1. To (Name and address of employer) Alejandro Rosalez 123 Any Street, Any Town, USA  2. From (Name and address of lender) Carlos Salazar 100 Main Street, Anytown, USA  I certify that this verification has been sent directly to the employer and has not passed through the hands of the applicant or any other interested party.  3. Signature of Lender Carlos Salazar  4. Title Project Manager  5. Date 12/12/2006  6. Lender's Number (Optional) 5555-5555-5555  I have applied for a mortgage loan and stated that I am now or was formerly employed by you. My signature below authorizes verification of this information.  7. Name and Address of Applicant (include employee or badge number) Paulo Santos 123 Any Street, Any Town, USA  8. Signature of Applicant Paulo Santos  Part II - Verification of Present Employment  9. Applicant's Date of Employment 06/06/2006  10. Present Position General Manager  11. Probability of Continued Employment 3 years  12A. Current Gross Base Pay (Enter Amount and Check Period) Annual $5600  12B. Gross Earnings  Type Year To Date Past Year Past Year Base Pay $15.00 $20.00 $30.00 Overtime $15.00 $20.00 $30.00 Commissions $20.00 $20.00 $15.00 Bonus $20.00 $20.00 $15.00 Total $70.00 $80.00 $90.00  13. For Military Personnel Only Pay Grade 10 Type Monthly Amount Base Pay $520  14. If Overtime or Bonus is Applicable, Is Its Continuance Likely? Overtime Yes No Bonus Yes No  15. If paid hourly - average hours per week 40 hours  16. Date of applicant's next pay increase 08/08/2007  17. Projected amount of next pay increase $5600  18. Date of applicant's last pay increase 09/08/2006  19. Amount of last pay increase $4800  20. Remarks (If employee was off work for any length of time, please indicate time period and reason) Not Applicable  Part III - Verification of Previous Employment  21. Date Hired 04/04/2004  22. Date Terminated 01/03/2005  23. Salary/Wage at Termination Per (Year) (Month) (Week) Base $9500 Overtime 1250 Commissions 4500 Bonus 4000  24. Reason for Leaving Medical Issue  25. Position Held Device Operator  Part IV - Authorized Signature - Federal statutes provide severe penalties for any fraud, intentional misrepresentation, or criminal connivance or conspiracy purposed to influence the issuance of any guaranty or insurance by the VA Secretary, the U.S.D.A., FmHA/FHA Commissioner, or the HUD/CPD Assistant Secretary.  26. Signature of Employer Richard Roe  27. Title (Please print or type) VA Secretary  28. Date 01/05/2007  29. Print or type name signed in item 26 Richard Roe  30. Phone No. 555-0100  Form 1005 July 96"
}**

# Request for Verification of Employment

**Privacy Act Notice:** This information is to be used by the agency collecting it or its assignees in determining whether you qualify as a prospective mortgagor under its program. It will not be disclosed outside the agency except as required and permitted by law. You do not have to provide this information, but if you do not, your application for approval as a prospective mortgagor or borrower may be delayed or rejected. The information requested in this form is authorized by Title 38, USC, Chapter 37 (if VA); by 12 USC, Section 1701 et. seq. (if HUD/FHA); by 42 USC, Section 1452b (if HUD/CPD); and Title 42 USC, 1471 et. seq., or 7 USC, 1921 et. seq. (if USDA/FmHA).

**Instructions:** Lender - Complete items 1 through 7. Have applicant complete item 8. Forward directly to employer named in item 1. Employer - Please complete either Part II or Part III as applicable. Complete Part IV and return directly to lender named in item 2. The form is to be transmitted directly to the lender and is not to be transmitted through the applicant or any other party.

## Part I - Request

1. To (Name and address of employer)
2. (Name and address of lender)
3. Alejandro Rosalez
4. (123 Any Street, Any Town, USA)
5. (100 Main Street, Anytown, USA)
6. (100 Main Street, Anytown, USA)

I certify that this verification has been sent directly to the employer and has not passed through the hands of the applicant or any other interested party.

|  3. Signature of Lender | 4. Title | 5. Date | 6. Lender's Number (Optional)  |
| --- | --- | --- | --- |
|  Carlos Salazar |  |  | 5555-5555-5555  |

I have applied for a mortgage loan and stated that I am now or was formerly employed by you. My signature below authorizes verification of this information.

|  7. Name and Address of Applicant (include employee or badge number) | 8. Signature of Applicant  |
| --- | --- |
|  Paulo Santos | Paulo Santos  |
|  123 Any Street, Any Town, USA |   |

## Part II - Verification of Present Employment

|  9. Applicant's Date of Employment | 10. Present Position | 11. Probability of Continued Employment  |
| --- | --- | --- |
|  06/06/2006 | General Manager | 3 years  |

|  12A. Current Gross Base Pay (Enter Amount and Check Period) | 13. For Military Personnel Only | 14. If Overtime or Bonus is Applicable, Is Its Continuance Likely?  |
| --- | --- | --- |
|  ☑ Annual | ☐ Hourly | ☐ 10  |
|  ☐ Monthly | ☐ Other (Specify) | ☐ 5600  |
|  ☐ Weekly |  |   |
|  ☐ 12B. Gross Earnings |  |   |
|  Type | ☐ Year To Date | ☐ Past Year  |
|  Base Pay | ☐ Thru 2006 | ☐ 20.00  |
|  ☐ 15.00 | ☐ 20.00 | ☐ 30.00  |
|  Overtime | ☐ 15.00 | ☐ 20.00  |
|  Overtime | ☐ 20.00 | ☐ 20.00  |
|  Commissions | ☐ 20.00 | ☐ 20.00  |
|  Bonus | ☐ 20.00 | ☐ 20.00  |
|  Total | ☐ $70.00 | ☐ $80.00  |

1. Remarks (if employee was off work for any length of time, please indicate time period and reason)

**Not Applicable**

## Part III - Verification of Previous Employment

|  21. Date Hired | 04/04/2004  |
| --- | --- |
|  22. Date Terminated | 01/03/2005  |
|  23. Salary/Wage at Termination Per (Year) (Month) (Week) |   |
|  24. Reason for Leaving | Medical Issue  |
|  Base | $9500  |
|  Overtime | 1250  |
|  Commissions | 4500  |
|  Bonus | 4000  |

25. Position Held

**Device Operator**

## Part IV - Authorized Signature

Federal statutes provide severe penalties for any fraud, intentional misrepresentation, or criminal connivance or conspiracy purposed to influence the issuance of any guaranty or insurance by the VA Secretary, the U.S.D.A., FmHA/FHA Commissioner, or the HUD/CPD Assistant Secretary.

|  26. Signature of Employer | 27. Title (Please print or type) | 28. Date  |
| --- | --- | --- |
|  Richard Roe | VA Secretary | 01/05/2007  |
|  29. Print or type name signed in item 26 | 30. Phone No. | 01/05/2007  |
|  Richard Roe | 555-0100 |   |
**{
  "language": "en",
  "summary": "The document is a Consumer Leasing Act Disclosure form detailing the terms of a vehicle lease. It includes information on the amount due at lease signing or delivery, monthly payments, other charges, and the total of payments. The form also breaks down the itemization of the amount due at lease signing, how this amount will be paid, and the calculation of the monthly payment. Additional terms cover early termination, excessive wear and use, purchase options at the end of the lease term, and other important terms related to the lease.",
  "authors": [],
  "extracted_text": "Consumer Leasing Act Disclosures 1. Amount Due at Lease Signing or Delivery 6882.00 2. Monthly Payments Your first Monthly Payment of $ 966.15 is due on 12/27/2019 , followed by 23 payments of $ 966.15 due on the 27th of each month. The total of your Monthly Payments is $ 23187.60 3. Other Charges (not part of your Monthly Payment) a. Vehicle Turn-In Fee (if you do not purchase the vehicle at Lease End) $ 595.00 b. N/A c. Total $ 595.00 4. Total of Payments (The amount you will have paid by the end of the lease) $ 29698.45 *5. Itemization of Amount Due at Lease Signing or Delivery a. Amount Due at Lease Signing or Delivery: 1. First Total Monthly Payment (includes sales/use taxes) $ 966.15 2. Capitalized Cost Reduction + $ 4421.86 3. Acquisition Fee (if not capitalized) + $ 1095.00 4. Sales/Use Taxes + $ N/A 5. Refundable Security Deposit + $ N/A 6. Title Fees + $ 108.50 7. License Fees + $ N/A 8. Registration Fees + $ N/A 9. CAP RED TAX + $ 40.49 10. DOC FEE + $ 250.00 11. N/A + $ N/A 12. N/A + $ N/A 13. Total $ 6882.00 b. How the Amount Due at Lease Signing or Delivery will be paid: 1. Net Trade-in Allowance $ 3882.00 2. Rebates and noncash credits + $ 3000.00 3. Amount to be paid in cash + $ N/A 4. N/A + $ N/A 5. Total $ 6882.00 6. Your monthly payment is determined as shown below: a. Gross Capitalized Cost: The agreed upon value of the vehicle ($ 68200.00 ) and any items you pay over the lease term (such as service contracts, insurance, and any outstanding prior credit or lease balance) $ 70115.52 b. Capitalized Cost Reduction: The amount of any net trade-in allowance, rebate, noncash credit, or cash you pay that reduces the Gross Capitalized Cost $ 4421.86 c. Adjusted Capitalized Cost: The amount used in calculating your Base Monthly Payment $ 65693.66 d. Residual Value: The value of the vehicle at the end of the lease used in calculating your Base Monthly Payment $ 44570.20 e. Depreciation and any amortized amounts: The amount charged for the vehicle's decline in value through normal use and for other items paid over the lease term $ 21123.46 f. Rent Charge: The amount charged in addition to the Depreciation and any amortized amounts $ 2064.14 g. Total of Base Monthly Payments: The Depreciation and any amortized amounts plus the Rent Charge $ 23187.60 h. Lease Payments: The number of payments in your lease 24 i. Base Monthly Payment $ 966.15 j. Monthly Sales/Use Taxes + $ N/A k. N/A + $ N/A l. Total Monthly Payment $ 966.15 7. Early Termination. You may have to pay a substantial charge if you end this lease early. The charge may be up to several thousand dollars. The actual charge will depend on when the lease is terminated. The earlier you end the lease, the greater this charge is likely to be. 8. Excessive Wear and Use. You may be charged for excessive wear based on our standards for normal use and for mileage in excess of 30,000 miles (Mileage Allowance) for the term of this lease, at the rate of 0.25 per mile. 9. Purchase Option at End of Lease Term. You have an option to purchase the vehicle (\"as is\") at the end of the lease term for $ 44570.20 , plus a Purchase Option Fee of $ 150.00 , plus all official fees and taxes. See the Purchase Option section on page 7 of this lease for more information. 10. Other Important Terms. See your lease documents for additional information on early termination, purchase options, maintenance responsibilities, warranties, late and default charges, insurance, and any security interest, if applicable."
}**

# Consumer Leasing Act Disclosures

1. Amount Due
at Lease
Signing or
Delivery
(Itemized below)*
$ 6882.00

2. Monthly Payments
Your first Monthly Payment of $ 966.15
is due on 12/27/2019 , followed by
23 payments of $ 966.15 due
on the 27th of each month. The total of
your Monthly Payments is $ 23187.60

3. Other Charges (not part of your Monthly
Payment)
a. Vehicle Turn-In Fee (if you
do not purchase the vehicle
at Lease End) $ 595.00
b. N/A $ N/A
c. Total $ 595.00 $ 29698.45

*5. Itemization of Amount Due at Lease Signing or
Delivery

a. Amount Due at Lease Signing or Delivery:
1. First Total Monthly Payment
(includes sales/use taxes) $ 966.15
2. Capitalized Cost Reduction + $ 4421.86
3. Acquisition Fee (if not capitalized) + $ 1095.00
4. Sales/Use Taxes + $ N/A
5. Refundable Security Deposit + $ N/A
6. Title Fees + $ 108.50
7. License Fees + $ N/A
8. Registration Fees + $ N/A
9. CAP RED TAX + $ 40.49
10. DOC FEE + $ 250.00
11. N/A + $ N/A
12. N/A + $ N/A
13. Total = $ 6682.00

b. How the Amount Due at Lease Signing or
Delivery will be paid:
1. Net Trade-In Allowance $ 3882.00
2. Rebates and noncash credits + $ 3000.00
3. Amount to be paid in cash + $ N/A
4. N/A + $ N/A
5. Total = $ 6682.00

6. Your monthly payment is determined as shown below:

a. Gross Capitalized Cost: The agreed upon
value of the vehicle ($ 66200.00) and any
items you pay over the lease term (such as
service contracts, insurance, and any
outstanding prior credit or lease balance) . . . . $ 70115.52

b. Capitalized Cost Reduction: The amount of
any net trade-in allowance, rebate, noncash
credit, or cash you pay that reduces the Gross
Capitalized Cost + $ 4421.86

c. Adjusted Capitalized Cost: The amount used
in calculating your Base Monthly
Payment + $ 65693.66

d. Residual Value: The value of the vehicle at the
end of the lease used in calculating your Base
Monthly Payment + $ 44570.20

e. Depreciation and any amortized amounts:
The amount charged for the vehicle's decline in
value through normal use and for other items
paid over the lease term . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
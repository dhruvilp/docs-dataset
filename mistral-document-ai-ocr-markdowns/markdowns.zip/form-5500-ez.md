**{
  "language": "en",
  "summary": "This document is an Annual Return of a One-Participant (Owners/Partners and Their Spouses) Retirement Plan or a Foreign Plan for the calendar year 2023. It includes identification information, basic plan details, and financial information for the plan administered by Acme Corp Software.",
  "authors": [
    "Internal Revenue Service (IRS)"
  ],
  "extracted_text": "Form 5500-EZ Annual Return of A One-Participant (Owners/Partners and Their Spouses) Retirement Plan or A Foreign Plan For the calendar plan year 2023 or fiscal plan year beginning (MM/DD/YYYY) 01/02/2022 and ending 01/02/2023 Part I Annual Return Identification Information A This return is: (1) the first return filed for the plan (3) the final return filed for the plan (2) an amended return (4) a short plan year return (less than 12 months) B Check box if filing under Form 5558 automatic extension special extension (enter description) C If this return is for a foreign plan, check this box (see instructions) D If this return is for the IRS Late Filer Penalty Relief Program, check this box (Must be filed on a paper Form with the IRS. See instructions) E If this is a retroactively adopted plan permitted by SECURE Act section 201, check here Part II Basic Plan Information enter all requested information. 1a Name of plan Annual Return plan 1b Three-digit plan number (PN) 586 1c Date plan first became effective (MM/DD/YYYY) 02/05/2022 2a Employer's name Acme Corp Software 2b Employer Identification Number (EIN) (Do not enter your Social Security Number) 735268329 2c Employer's telephone number 011536259 2d Business code (see instructions) Mailing address (room, apt., suite no. and street, or P.O. box) 235 Park Street Avenue, FL 63052 City or town, state or province, country, and ZIP or foreign postal code (if foreign, see instructions) 3a Plan administrator's name (if same as employer, enter 'Same') 3b Administrator's EIN 532678 3c Administrator's telephone number Mailing address (room, apt., suite no. and street, or P.O. box) City or town, state or province, country, and ZIP or foreign postal code (if foreign, see instructions) 4 If the employer's name, the employer's EIN, and/or the plan name has changed since the last return filed for this plan, enter the employer's name and EIN, the plan name, and the plan number for the last return in the appropriate space provided 4a Employer's name 4b EIN 5732900 4c Plan name 4d PN 5a(1) Total number of participants at the beginning of the plan year 10 5a(2) Total number of active participants at the beginning of the plan year 8 5b(1) Total number of participants at the end of the plan year 5 5b(2) Total number of active participants at the end of the plan year 5c Number of participants who terminated employment during the plan year with accrued benefits that were less than 100% vested 2 Part III Financial Information 6a Total plan assets $50000 $60000 6b Total plan liabilities 4000 5000 6c Net plan assets (subtract line 6b from 6a)"
}**

Form Number: CA530082

Form 5500-EZ
Annual Return of A One-Participant (Owners/Partners and
Their Spouses) Retirement Plan or A Foreign Plan
This form is required to be filed under section 6058(a) of the Internal Revenue Code.
Certain foreign retirement plans are also required to file this form (see instructions).
Complete all entries in accordance with the instructions to the Form 5500-EZ.
Go to www.irs.gov/Form5500EZ for instructions and the latest information.
OMB No. 1545-1610
2023
This Form is Open
to Public Inspection.
Department of the Treasury
Internal Revenue Service
Part I Annual Return Identification Information
For the calendar plan year 2023 or fiscal plan year beginning (MM/DD/YYYY) 01/02/202-2and ending 01/02/2023
A This return is: (1) the first return filed for the plan (3) the final return filed for the plan
(2) an amended return (4) a short plan year return (less than 12 months)
B Check box if filing under [ ] Form 5558 [ ] automatic extension
[ ] special extension (enter description)
C If this return is for a foreign plan, check this box (see instructions)
D If this return is for the IRS Late Filer Penalty Relief Program, check this box
(Must be filed on a paper Form with the IRS. See instructions).
E If this is a retroactively adopted plan permitted by SECURE Act section 201, check here.
Part II Basic Plan Information - enter all requested information.
1a Name of plan
Annual Return plan
2a Employer's name ACme Corp software
Trade name of business (if different from name of employer)
In care of name
Mailing address (room, apt., suite no. and street, or P.O. box)
235, Park street Avenue, FL
City or town, state or province, country, and ZIP or foreign postal code (if foreign, see instructions)
FL 63052
3a Plan administrator's name (if same as employer, enter "Same")
In care of name
Mailing address (room, apt., suite no. and street, or P.O. box)
City or town, state or province, country, and ZIP or foreign postal code (if foreign, see instructions)
4 If the employer's name, the employer's EIN, and/or the plan name has changed since the
last return filed for this plan, enter the employer's name and EIN, the plan name, and the
plan number for the last return in the appropriate space provided
a Employer's name
4b EIN 5732900
4c Plan name
4d PN
5a(1) Total number of participants at the beginning of the plan year
5e(1) 10
a(2) Total number of active participants at the beginning of the plan year
5e(2) 8
b(1) Total number of participants at the end of the plan year
5b(1) 5
b(2) Total number of active participants at the end of the plan year
5b(2)
c Number of participants who terminated employment during the plan year with accrued
benefits that were less than 100% vested
5c 2
Part III Financial Information
6a Total plan assets
6a 50000 60000
6b 4000 5000
6c
For Privacy Act and Paperwork Reduction Act Notice, see the Instructions for Form 5500-EZ. Catalog Number 63263R Form 5500-EZ (2023)
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 50000 60000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 4000 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 5000 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 6000
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 400 5000
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 400 500
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 40 5000
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 400 500
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 40 500
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 40 500
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 40 500
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 40 500
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 40 500
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 40 500
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 40 500
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 40 500
6c
(1) Beginning of year
(2) End of year
6a 500
6c
(1) Beginning of year
(2) End of year
6a 500
6c
(1) Beginning of year
(2) End of year
6a 500 600
6b 40 500
6c
(1) Beginning of year
(2) End of year
6a 500
6c
(1) Beginning of year
(2) End of year
6a 500
6c
(1) Beginning of year
(2) End of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year
6a 500
6c
(1) Beginning of year

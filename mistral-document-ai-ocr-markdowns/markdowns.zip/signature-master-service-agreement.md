**{
  "language": "en",
  "summary": "This document is a Master Services Agreement between Gulf Coast State College and BankMobile Technologies, Inc. The agreement outlines the provision of services by BankMobile to the college, with key dates including the effective date, project start date, and go-live date. The agreement is valid for an initial term ending on March 10, 2025, with automatic renewals unless terminated with proper notice.",
  "authors": [
    "Andrew Crawford",
    "John Mercer"
  ],
  "extracted_text": "MASTER SERVICES AGREEMENT  \"Institution\": Gulf Coast State College  \"Institution Address\": Panama City, FL 32401  \"Effective Date\": March 11, 2020  \"Project Start Date\": March 20, 2020  \"Go-Live Date\": June 15, 2020  This BankMobile Technologies, Inc. Services Agreement (together with all exhibits hereto, this \"Agreement\") is entered into as of the Effective Date between BankMobile Technologies, Inc, a wholly owned subsidiary of Customers Bank, a Pennsylvania corporation located at 1015 Penn Avenue, Suite 103, Wyomissing, PA 19610 (hereinafter \"BankMobile\") and the Institution.  WHEREAS, the Institution desires that BankMobile provide the Services (as described in Exhibit A and defined in Exhibit B hereto) to the Institution; and  WHEREAS, BankMobile desires to deliver such Services under the terms set forth in Exhibits A and B attached hereto.  NOW, THEREFORE, in consideration of the mutual promises and covenants contained herein and other good and valuable consideration, the receipt and sufficiency of which is hereby acknowledged, BankMobile and the Institution hereby agree as follows:  BankMobile and the Institution will implement the Services described in the Exhibits on the following timeline:  For purposes of this Agreement, the \"Go-Live Date\" shall be the date on which implementation is complete and funds disbursement is fully operational.  The initial term of this Agreement will end on March 10, 2025. This Agreement will automatically renew for three additional periods of three (3) years at the published prices in effect at the time of renewal unless, at least 120 days prior to the end of the current term, either party gives the other a written notice of termination.  Exhibit A (Description of Services) and Exhibit B (Terms and Conditions) are incorporated into this Agreement by reference.  IN WITNESS WHEREOF, the Institution and BankMobile have caused this Agreement to be executed as of the Effective Date.  BankMobile  Andrew M.  By: Crawford  Digitally signed by Andrew M. Crawford  Date:2020.03.17 10:05:22 -04'00'  Name: Andrew Crawford  Title: CCO  Date:  Institution  By:  Name: John Mercer  Title: VP Administrative Services  Date:"
}**

# MASTER SERVICES AGREEMENT

**"Institution": Gulf Coast State College**

**"Institution Address": Panama City, FL 32401**

**"Effective Date": March 11, 2020**

**"Project Start Date": March 20, 2020**

**"Go-Live Date": June 15, 2020**

This BankMobile Technologies, Inc. Services Agreement (together with all exhibits hereto, this "Agreement") is entered into as of the Effective Date between BankMobile Technologies, Inc, a wholly owned subsidiary of Customers Bank, a Pennsylvania corporation located at 1015 Penn Avenue, Suite 103, Wyoming, PA 19610 (hereinafter "BankMobile") and the Institution.

WHEREAS, the Institution desires that BankMobile provide the Services (as described in Exhibit A and defined in Exhibit B hereto) to the Institution; and

WHEREAS, BankMobile desires to deliver such Services under the terms set forth in Exhibits A and B attached hereto.

NOW, THEREFORE, in consideration of the mutual promises and covenants contained herein and other good and valuable consideration, the receipt and sufficiency of which is hereby acknowledged, BankMobile and the Institution hereby agree as follows:

BankMobile and the Institution will implement the Services described in the Exhibits on the following timeline:

For purposes of this Agreement, the "Go-Live Date" shall be the date on which implementation is complete and funds disbursement is fully operational.

The initial term of this Agreement will end on **March 10, 2025**. This Agreement will automatically renew for three additional periods of three (3) years at the published prices in effect at the time of renewal unless, at least 120 days prior to the end of the current term, either party gives the other a written notice of termination.

Exhibit A (Description of Services) and Exhibit B (Terms and Conditions) are incorporated into this Agreement by reference.

IN WITNESS WHEREOF, the Institution and BankMobile have caused this Agreement to be executed as of the Effective Date.

|  BankMobile |   |
| --- | --- |
|  **Address:** | **Institution**  |
|  Andrew M. Crawford |   |
|  **Date:** | **Date:** 2020.03.17 10:05:22 -04'00'  |
|  **Name:** | **Address:**  |
|  Andrew Crawford |   |
|  **Title:** | **CCO**  |
|  **Date:** |   |

**Institution**

By: ***_******_******_******_***__

**Name:** John Mercer

**Title:** VP Administrative Services

**Date:** ***_******_******_******_***__

v.BM.18.1 | Page 1
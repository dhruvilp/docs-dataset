**{
  "language": "en",
  "summary": "This document is a claim form for a group health insurance policy. It includes details of the primary insured, insurance history, and the insured person who was hospitalized. The form is filled with handwritten information such as names, addresses, policy numbers, and medical history.",
  "authors": [],
  "extracted_text": "Claim Form - 'GROUP CARE' Part A 1. To be filled in by the Insured. 2. The issue of this form is not to be taken as an admission of liability. 3. To be filled in block letters. Section A - Details of Primary Insured a) Policy No.: ABCDEFGHIJKLMN12345678901010ABKXZ b) SL No./Certificate No.: 87654321342 c) Company/TPA ID No.: XYZ2461239 d) Name: Avanad Kanakejiri e) Address: 1209 35B Cross 4th Block Jayanagar City: Bangalore State: Karnataka Pin Code: 560041 Landline: 0080 22343202 Mobile: 772878262 E-mail: kanandichotmail.com Section B - Details of Insurance History a) Currently covered by any other Medicaid/Health Insurance: Yes b) Date of commencement of first insurance without break: 01/01/2018 c) If yes, Company Name: Swiss Re Americas Policy Number: 33241351BC123 Sum Insured (Rs.): 700000 d) Have you ever been hospitalized in the last 4 years since inception of the contract? Yes Date: Diagnosis: Erythroblastosis Fetalis e) Previously covered by any other Medicaid/Health Insurance: Yes f) If yes, Company Name: Dada J P Dhanki Limited Section C - Details of Insured Person Hospitalised Title: Mr. a) Name: Rommic Screwaca b) Gender: M c) Age: 98 d) Date of Birth: 01/01/1932 e) Relationship with Primary Insured: Self f) Occupation: Service g) Address: 46032 Sudhramaira Rd City: Bangalore State: Karnataka Pin Code: Landline: Mobile: E-mail: Religare Health Insurance Company Limited Registered Office: 5th Floor, 19 Chawri House, Nehru Place, New Delhi-110019 Corporate Office: Vignl Tech Square, Tower C, 3rd Floor, Golf Course Rd, Sec-43, Gurgaon-122009 (Haryana) Website: www.religarehealthinsurance.com E-mail: customerfirst@religarehealthinsurance.com Call us: 1800-200-4488 | 1860-500-4488 CIN: U66000DL2007PLC161503 UIN: IRDA/ML-HL/HRM/P-H/13/14-148 IRDA Registration No. - 148"
}**

# RELIGARE Health Insurance

**Alb Health Hamesha**

## Claim Form - 'GROUP CARE'

### Part A

1. To be filled in by the Insured.
2. The issue of this Form is not to be taken as an admission of liability.
3. To be filled in block letters.

### Section A - Details of Primary Insured

a) Policy No. 11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111
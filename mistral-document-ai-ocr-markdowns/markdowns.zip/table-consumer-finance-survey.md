**{
  "language": "en",
  "summary": "The document presents data from the 1998 Survey of Consumer Finances, focusing on direct and indirect family holdings of stock across different years (1989, 1992, 1995, and 1998). It includes statistics on the percentage of families owning stocks, the median value of these holdings, and the share of stock holdings as part of the group's financial assets. The data is categorized by family income levels and the age of the head of the family. Key observations include an increase in stock holdings from 1995 to 1998, with notable growth among higher-income families. The document also notes that declines in stock holdings were more pronounced among lower-income groups.",
  "authors": ["Federal Reserve Board"],
  "extracted_text": "Results from the 1998 Survey of Consumer Finances  Direct and indirect family holdings of stock, by selected characteristics of families, 1989, 1992, 1995, and 1998 surveys  Percent except as noted  Family characteristic Families having stock holdings, direct or indirect Median value among families with holdings (thousands of 1998 dollars) Stock holdings as share of group's financial assets  1989 1992 1995 1998 1989 1992 1995 1998 1989 1992 1995 1998  All families 31.6 36.7 40.4 48.8 10.8 12.0 15.4 25.0 27.8 33.7 40.0 53.9  Income (1998 dollars)  Less than 10,000 4 6.8 5.4 7.7 4 6.2 3.2 4.0 4 15.9 12.9 24.8  10,000–24,999 12.7 17.8 22.2 24.7 6.4 4.6 6.4 9.0 11.7 15.3 26.7 27.5  25,000–49,999 31.5 40.2 45.4 52.7 6.0 7.2 8.3 11.5 16.9 23.7 30.3 39.1  50,000–99,999 51.5 62.5 65.4 74.3 10.2 15.4 23.6 35.7 23.2 33.5 38.9 48.8  100,000 or more 81.8 78.3 81.6 91.0 53.5 71.9 85.5 150.0 35.3 40.2 46.4 63.0  Age of head (years)  Less than 35 22.4 28.3 36.6 40.7 3.8 4.0 5.4 7.0 20.2 24.8 27.2 44.8  35–44 38.9 42.4 46.4 56.5 6.6 8.6 10.8 20.0 29.2 31.0 39.5 54.7  45–54 41.8 46.4 48.9 58.6 16.7 17.1 27.6 38.0 33.5 40.6 42.9 55.7  55–64 36.2 45.3 48.0 55.9 25.4 28.5 32.9 47.0 27.6 37.3 44.4 58.3  65–74 26.7 30.2 34.4 42.6 25.8 18.3 36.1 56.0 26.0 31.6 35.8 51.3  75 or more 25.9 25.7 27.9 29.4 31.8 28.5 21.2 60.0 25.0 25.4 39.8 48.7  1995 to 89.9 percent in 1998. Declines were spread fairly evenly over most demographic groups except the income and net worth groups, in which the decreases were largest for families at the lower ends of the scales. The median holding of nonfinancial assets of $100,000 or more. However, between the 1995 and 1998 surveys, the growth of leasing among families in that income group had leveled off, while it had picked up among families with incomes below $50,000."
}**

1. Direct and indirect family holdings of stock, by selected characteristics of families, 1989, 1992, 1995, and 1998 surveys Percent except as noted

|  Family characteristic | Families having stock holdings, direct or indirect ${ }^{1}$ |  |  |  | Median value among families with holdings (thousands of 1998 dollars) |  |  |  | Stock holdings as share of group's financial assets |  |  |   |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|   | 1989 | 1992 | 1995 | 1998 | 1989 | 1992 | 1995 | 1998 | 1989 | 1992 | 1995 | 1998  |
|  All families | 31.6 | 36.7 | 40.4 | 48.8 | 10.8 | 12.0 | 15.4 | 25.0 | 27.8 | 33.7 | 40.0 | 53.9  |
|  Income (1998 dollars) |  |  |  |  |  |  |  |  |  |  |  |   |
|  Less than 10,000 | 4 | 6.8 | 5.4 | 7.7 | 4 | 6.2 | 3.2 | 4.0 | 4 | 15.9 | 12.9 | 24.8  |
|  10,000-24,999 | 12.7 | 17.8 | 22.2 | 24.7 | 6.4 | 4.6 | 6.4 | 9.0 | 11.7 | 15.3 | 26.7 | 27.5  |
|  25,000-49,999 | 31.5 | 40.2 | 45.4 | 52.7 | 6.0 | 7.2 | 8.5 | 11.5 | 16.9 | 23.7 | 30.3 | 39.1  |
|  50,000-99,999 | 51.5 | 62.5 | 65.4 | 74.3 | 10.2 | 15.4 | 23.5 | 35.7 | 23.2 | 35.5 | 39.9 | 48.8  |
|  100,000 or more | 81.8 | 78.3 | 81.6 | 91.0 | 53.5 | 71.9 | 85.5 | 150.0 | 35.3 | 40.2 | 46.4 | 63.0  |
|  Age of head (years) |  |  |  |  |  |  |  |  |  |  |  |   |
|  Less than 35 | 22.4 | 28.3 | 36.6 | 40.7 | 3.8 | 4.0 | 5.4 | 7.0 | 20.2 | 24.8 | 27.2 | 44.8  |
|  35-44 | 38.9 | 42.4 | 46.4 | 56.5 | 6.6 | 8.6 | 10.5 | 20.0 | 29.2 | 31.0 | 39.5 | 54.7  |
|  45-54 | 41.8 | 46.4 | 48.9 | 58.6 | 16.7 | 17.1 | 27.5 | 38.0 | 33.5 | 40.6 | 42.9 | 55.7  |
|  55-64 | 36.2 | 45.3 | 40.0 | 55.9 | 23.4 | 28.5 | 32.9 | 47.0 | 27.6 | 37.3 | 44.4 | 58.3  |
|  65-74 | 26.7 | 30.2 | 34.4 | 42.6 | 25.8 | 18.3 | 36.1 | 56.0 | 26.0 | 31.6 | 35.8 | 51.3  |
|  75 or more | 25.9 | 25.7 | 27.9 | 29.4 | 31.8 | 28.5 | 21.2 | 60.0 | 25.0 | 25.4 | 39.8 | 48.7  |

Non. See note to table 1.

1. Indirect holdings are those in mutual funds, retirement accounts, and other managed assets.
2. Ten or fewer observations.

1995 to 89.9 percent in 1998. Declines were spread fairly evenly over most demographic groups except the income and net worth groups, in which the decreases were largest for families at the lower ends of the scales. The median holding of nonfinancial of $\$ 100,000$ or more. However, between the 1995 and 1998 surveys, the growth of leasing among families in that income group had leveled off, while it had picked up among families with incomes below $\$ 50,000$.
**{
  "language": "en",
  "summary": "This document is a New York State Substitute Form W-9, used to request taxpayer identification numbers and certifications. It includes sections for vendor information, taxpayer identification, address, certification, and vendor contact information. The form is filled out by an individual named John Smith, who is an individual sole proprietor residing at 16 Candy Cane Lane, NY, NY 12345. The form is dated 10/28/15.",
  "authors": ["New York State Office of the State Comptroller"],
  "extracted_text": "NEW YORK STATE OFFICE OF THE STATE COMPTROLLER SUBSTITUTE FORM W-9: REQUEST FOR TAXPAYER IDENTIFICATION NUMBER & CERTIFICATION TYPE OR PRINT INFORMATION NEATLY. PLEASE REFER TO INSTRUCTIONS FOR MORE INFORMATION. Part I: Vendor Information 1. Legal Business Name: John Smith 2. Business name/disregarded entity name, if different from Legal Business Name: N/A 3. Entity Type (Check one only): [X] Individual Sole Proprietor [ ] Partnership [ ] Limited Liability Co. [ ] Corporation [ ] Not For Profit [ ] Trusts/Estates [ ] Federal, State or Local Government [ ] Public Authority [ ] Disregarded Entity [ ] Exempt Payee [ ] Other Part II: Taxpayer Identification Number (TIN) & Taxpayer Identification Type 1. Enter your TIN here: (DO NOT USE DASHES) 1 2 3 4 5 6 7 8 9 2. Taxpayer Identification Type (check appropriate box): [ ] Employer ID No. (EIN) [X] Social Security No. (SSN) [ ] Individual Taxpayer ID No. (ITIN) [ ] N/A (Non-United States Business Entity) Part III: Address 1. Physical Address: Number, Street, and Apartment or Suite Number 16 Candy Cane Lane City, State, and Nine Digit Zip Code or Country NY, NY 12345 2. Remittance Address: Number, Street, and Apartment or Suite Number N/A City, State, and Nine Digit Zip Code or Country N/A Part IV: Certification and Exemption from Backup Withholding Under penalties of perjury, I certify that: 1. The number shown on this form is my correct taxpayer identification number (TIN), and 2. I am a U.S. citizen or other U.S. person, and 3. (Check one only): [X] I am not subject to backup withholding. I am (a) exempt from back up withholding, or (b) I have not been notified by the Internal Revenue Service (IRS) that I am subject to backup withholding as a result of a failure to report all interest or dividends, or (c) the IRS has notified me that I am no longer subject to backup withholding, or [ ] I am subject to backup withholding. I have been notified by the IRS that I am subject to backup withholding as a result of a failure to report all interest or dividends, and I have not been notified by the IRS that I am no longer subject to back withholding. Sign Here: Signature Date 10/28/15 SBTE Title John Smith Print Preparer's Name (585) 123-4567 Phone Number jsmith@abcschools.org Email Address Part V: Vendor Primary Contact Information - Executive Authorized to Represent the Vendor Primary Contact Name: John Smith Title: School-based Teacher Educator Email Address: jsmith@abcschools.org Phone Number: (585) 123-4567 DO NOT SUBMIT FORM TO IRS - SUBMIT FORM TO NYS ONLY AS DIRECTED"
}**

# NEW YORK STATE OFFICE OF THE STATE COMPTROLLER
SUBSTITUTE FORM W-9:
REQUEST FOR TAXPAYER IDENTIFICATION NUMBER & CERTIFICATION

TYPE OR PRINT INFORMATION NEATLY. PLEASE REFER TO INSTRUCTIONS FOR MORE INFORMATION.

Part I: Vendor Information
1. Legal Business Name:
John Smith
2. Business name/disregarded entity name, if different from Legal
Business Name:
N/A

3. Entity Type (Check one only):
[x] Individual Sole Proprietor [ ] Partnership [ ] Limited Liability Co. [ ] Corporation [ ] Not For Profit
Trusts/Estates [ ] Federal, State or Local Government [ ] Public Authority [ ] Disregarded Entity [ ] Exempt
[ ] Other
Payee

Part II: Taxpayer Identification Number (TIN) & Taxpayer Identification Type
1. Enter your TIN here: (DO NOT USE DASHES)
See instructions.
1
2
3
4
5
6
7
8
9

2. Taxpayer Identification Type (check appropriate box):
[ ] Employer ID No. (EIN) [x] Social Security No. (SSN) [ ] Individual Taxpayer ID No. (ITIN) [ ] N/A (Non-United States Business Entity)

Part III: Address
1. Physical Address:
Number, Street, and Apartment or Suite Number
16 Candy Cane Lane
2. Remittance Address:
Number, Street, and Apartment or Suite Number
N/A

City, State, and Nine Digit Zip Code or Country
NY, NY 12345
City, State, and Nine Digit Zip Code or Country
N/A

Part IV: Certification and Exemption from Backup Withholding
Under penalties of perjury, I certify that:
1. The number shown on this form is my correct taxpayer identification number (TIN), and
2. I am a U.S. citizen or other U.S. person, and
3. (Check one only):
[ ] I am not subject to backup withholding. I am (a) exempt from back up withholding, or (b) I have not been notified by the
Internal Revenue Service (IRS) that I am subject to backup withholding as a result of a failure to report all interest or dividends, or
(c) the IRS has notified me that I am no longer subject to backup withholding), or
[ ] I am subject to backup withholding. I have been notified by the IRS that I am subject to backup withholding as a result of a
failure to report all interest or dividends, and I have not been notified by the IRS that I am no longer subject to back withholding.

Sign Here:
Signature
John Smith
John Smith
Print Preparer's Name
SBTE
Title
(585) 123-4567
Phone Number
10/28/15
Date
jsmith@abcschools.org
Email Address

Part V: Vendor Primary Contact Information - Executive Authorized to Represent the Vendor

Primary Contact Name: John Smith
Email Address: jsmith@abcschools.org
Title: School-based Teacher Educator
Phone Number:
(585) 123-4567

DO NOT SUBMIT FORM TO IRS - SUBMIT FORM TO NYS ONLY AS DIRECTED
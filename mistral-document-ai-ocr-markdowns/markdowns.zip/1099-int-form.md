**{
  "language": "en",
  "summary": "This document is a Form 1099-INT, which is used to report interest income received during the year 2020. It details various types of interest income, including early withdrawal penalties, interest on U.S. savings bonds, and tax-exempt interest. The form is issued by Tempo Bank to Jim I. Beam, providing specific financial information required for tax reporting purposes.",
  "authors": ["Internal Revenue Service (IRS)"],
  "extracted_text": "Tempo Bank 987 Broadway St. Trenton, IL 62293 88-8888888 2020 250.00 50.00 400.00 150.00 Jim I. Beam 123 Second St. Trenton, IL 62293 222-22-2222 ABC 098"
}**

☐ CORRECTED (if checked)
or foreign postal code, and telephone no.
☐ 297
Payer's RTN (optional)
OMB No. 1545-0112

1 Interest income
2020
2 Early withdrawal penalty
Farm 1099-INT
Payer's TIN
RECIPIENT'S TIN
$ 50.00
3 Interest on U.S. Savings Bonds and Treas. obligations
For Recipient
88-8888888
222-22-2222
$ 400.00
RECIPIENT'S name
Jim I. Beam
Street address (including apt. no.)
123 Second St,
City or town, state or province, country, and ZIP or foreign postal code
Trenton, IL 62293
FATCA filing
requirement
☐
12 Bond pension or Treasury obligation
13 Bond pension on tax-exempt bond
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
ABC 098
123 Second St,
City or town, state or province, country, and ZIP or foreign postal code
Trenton, IL 62293
A 123 Second St,
City or town, state or province, country, and ZIP or foreign postal code
Trenton, IL 62293
FATCA filing
requirement
☐
12 Bond pension or Treasury obligation
13 Bond pension on tax-exempt bond
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
ABC 098
123 Second St,
City or town, state or province, country, and ZIP or foreign postal code
Trenton, IL 62293
FATCA filing
requirement
☐
12 Bond pension or Treasury obligation
13 Bond pension on tax-exempt bond
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
ABC 098
123 Second St,
City or town, state or province, country, and ZIP or foreign postal code
Trenton, IL 62293
FATCA filing
requirement
☐
12 Bond pension or Treasury obligation
13 Bond pension on tax-exempt bond
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
Amount
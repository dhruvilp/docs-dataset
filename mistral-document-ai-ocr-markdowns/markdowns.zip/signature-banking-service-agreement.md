**{
  "language": "en",
  "summary": "This document is a banking services agreement between the City of Lake Worth Beach, Florida, and JPMorgan Chase Bank, N.A. It includes signatures and attestations from various officials, including the Mayor, City Clerk, City Attorney, and Financial Services Director. The agreement was acknowledged by a notary public on September 24, 2021.",
  "authors": [
    "Bethy Resch, Mayor",
    "Melissa Ann Coyne, City Clerk",
    "Glen J. Torcivia, City Attorney",
    "Bruce T. Miller, Financial Services Director",
    "Thascar R. Hildebrandt, Authorized Officer, JPMorgan Chase Bank, N.A.",
    "Alexis Davis, Notary Public"
  ],
  "extracted_text": "IN WITNESS WHEREOF the parties hereto have made and executed this BANKING SERVICES AGREEMENT on the day and year first above written. CITY OF LAKE WORTH BEACH, FLORIDA By: Bethy Resch, Mayor ATTEST: By: Melissa Ann Coyne, City Clerk APPROVED AS TO FORM AND LEGAL SUFFICIENCY: By: Glen J. Torcivia, City Attorney APPROVED FOR FINANCIAL SUFFICIENCY By: Bruce T. Miller, Financial Services Director BANK: JPMorgan Chase Bank, N.A. By: Thascar R. Hildebrandt Print Name: Thascar R. Hildebrandt Title: Authorized Officer STATE OF Florida COUNTY OF Miami-Dade THE FOREGOING instrument was acknowledged before me by means of physical presence or online notarization on this 24th day of September 2021, by Thascar Hildebrandt, as the Authorized Officer [title] of J.P. Morgan Chase Bank, N.A. a National Association, who is personally known to me or who has produced FL Driver's License as identification, and who did take an oath that he or she is duly authorized to execute the foregoing instrument and bind the BANK to the same. Notary Public Signature Notary Seal: ALEXIS DAVIS Notary Public - State of Florida Commission # GG 207106 My Comm. Expires Jun 12, 2022"
}**

IN WITNESS WHEREOF the parties hereto have made and executed this **BANKING SERVICES AGREEMENT** on the day and year first above written.

CITY OF LAKE WORTH BEACH, FLORIDA

ATTEST:

By: _Bethy Resch, Mayor

By: _Melissa Ann Coyne, City Clerk

APPROVED AS TO FORM AND LEGAL SUFFICIENCY:

By: _Glen J. Torcivia, City Attorney

APPROVED FOR FINANCIAL SUFFICIENCY

By: _Bruce T. Miller, Financial Services Director

BANK: **JPMorgan Chase Bank, N.A.**

By: _Print Name: _Huscar R. Hillcrest_

Title: _Authorized Officer_

STATE OF _Florida_

COUNTY OF _Miami, Dade_

THE FOREGOING instrument was acknowledged before me by means of **physical presence** or **online notarization** on this **79th** day of **September**, 2021, by **Huscar Hillcrest**, as the **Authorized Officer** [title] of **J.P. Morgan Chase Bank, N.A.** a National Association, who is personally known to me or who has produced **FL Driess License**, as identification, and who did take an oath that he or she is duly authorized to execute the foregoing instrument and bind the BANK to the same.

Notary Public Signature

Notary Seal:

**ALEXIS DAVIS**
Notary Public - State of Florida
Commission # GG 207106
My Comm. Expires Jun 12, 2022
**{
  "language": "en",
  "summary": "The document is a 'Schedule A to Merchant Agreement' between Chase (J.P. Morgan) and the City of Lake Worth Beach. It outlines various fees and assumptions related to payment transactions, including transaction-related assumptions, other assumptions, fees applied on every transaction, transaction fees, authorization fees, one-time and periodic fees, per incidence fees, card network fees, equipment swap fees, and card network charges. The document also includes a section for authorized signatures.",
  "authors": [
    "Chase (J.P. Morgan)"
  ],
  "extracted_text": "CHASE Schedule A to Merchant Agreement J.P. Morgan Merchant: City of Lake Worth Beach NAPFINSCHEDAICPT2F 202104 Assumptions Transaction related assumptions Payment Transaction Sales Volume $1,400,000 Average Transaction Amount $49.00 Debit / EBT Transactions 0 Conveyed Transactions N/A Safetech Encrypted Items N/A Number of locations 3 Authorization / Capture % 135.0% Chargebacks as % of Sales Transactions 0.0300% Billing Frequency Monthly Target Qualification Level: Mastercard: Public Sector MUPS Visa: CPS Retail 2 (Emerging Markets) VCR2 American Express: Emerging Market - Tier 1 AEM1 Discover: PSL Public Services - Core D161 1. Fees applied on every transaction Card Network Interchange & any incremental discount rate % – Mastercard, Visa and Discover assess an Interchange Rate, Assessment Fee and Network Fee for each transaction. American Express assesses a Wholesale Discount Rate and Network Fee for each transaction. These rates and fees will be passed through at cost. Interchange and Wholesale Discount Rates as set by each Card Network MasterCard, Visa & Discover Incremental Discount Rate 0.1500% American Express Incremental Discount Rate 0.1500% PIN Debit, PINLess Debit, and/or EBT Network Fees All standard Debit Network Fees will be assessed N/A Debit – Incremental Discount Rate JCB (Japanese Credit Bureau) N/A Voyager Discount Rate (if settled) N/A Wright Express (WEX) Discount Rate (if settled) N/A Card Network Assessments Mastercard Credit transactions < $1000 and all Debit transactions 0.130% Credit transactions > $1000 0.140% Visa Debit transactions 0.130% Credit transactions 0.140% American Express OptBlue Network Fee 0.160% Discover 0.130% Card Network Fees Mastercard Network Access & Brand Usage Fee (NABU) (Charged per Authorization & per Refund) Credit $0.0195 Debit $0.0195 Visa Domestic Sales Auth (APF) (Charged per Authorization & per Refund) Credit $0.0195 Debit $0.0155 Visa Intl Sales Auth (APF) (Charged per Authorization & per Refund) Credit $0.0395 Debit $0.0355 Discover Data Usage Fee Credit $0.0025 Debit $0.0025 Card Network Fees MC Connectivity Fee* (per Transaction and Authorization) $0.0014 MC Reporting & Infrastructure $0.0003 VI Financial Transaction Fee $0.0018 VI Reporting & Data Transfer $0.0002 *In some cases, it is not possible to allocate the associated expenses from the payment networks directly to transaction counts or volume, so Chase Merchant Services produces a rate that is based on the associated expense from the payment networks and applies that expense accordingly. Customer initials x Please initial to acknowledge pg. 1 of the Schedule A pricing sheet CONTROL NUMBER: 657310.V3211 Printed: April 29, 2021 Page 1 of 4 Transaction Fees Mastercard per transaction N/A Visa per transaction N/A Discover per transaction N/A JCB per transaction N/A American Express per transaction N/A PIN Debit per transaction N/A PINLess Debit per transaction N/A EBT per transaction N/A Check Verification – Scan per transaction N/A Voyager per transaction N/A Wright Express per transaction N/A Hosted Pay Page per transaction N/A Managed POS Vendor per transaction N/A Authorization Fees Mastercard per authorization $0.1000 Visa per authorization $0.1000 Discover per authorization $0.1000 JCB per authorization N/A American Express per authorization $0.1000 Voyager per authorization N/A Wright Express per authorization N/A Private Label per authorization N/A Dial Backup authorization surcharge $0.0100 Other Transaction Fees Safetech Encryption per transaction N/A Safetech Tokenization per transaction N/A Level III Purchasing Card per transaction N/A 2. One Time and Periodic Fees One Time Fees Account Setup Fee N/A Rush Fee N/A Terminal Reprogram Fee N/A PIN Debit Setup Fee N/A PIN Pad Encryption Fee N/A Monthly Fees Monthly Service Fee 1 $2.50 Monthly Minimum Fee 2 $25.00 Online Reporting Tool N/A Safetech Encryption 3 N/A Managed POS Vendor per Terminal N/A Periodic Fees Annual Fee N/A Card Network Fees Visa Fixed Acquirer Network Fee 4 Varies MC Merchant Location Fee 5 $1.25 Frame Relay: Setup Fee N/A Monthly Fee N/A Third Party Setup Fee N/A Third Party Monthly Fee N/A JPM Payments Platform JPM Payments Platform Transaction Fee N/A JPM Payments Platform Setup Fee N/A JPM Payments Platform Monthly Fee N/A 3. Per Incidence Fees 3A. Per Incidence Fees: Charged every time the Merchant’s account incurs one of the below items Chargeback Fee $10.00 Charged when a cardholder or card-issuing bank formally protests a charge Voice Authorization Fee $0.65 Charged when the Voice Authorization phone number is called to authorize a credit card AVS Fee – Electronic N/A Charge for each electronic address verification authorization Batch Settlement Fee N/A Charged for each batch of transaction(s) submitted for settlement ACH fee N/A Charged for each ACH (transmission of funds) sent to your account ACH Return Fee $25.00 Charged when CMS is unable to debit fees from Merchant’s account Customer initials x Please initial to acknowledge pg. 2 of the Schedule A pricing sheet CONTROL NUMBER: 657310.V3211 Printed: April 29, 2021 Page 2 of 4 3B. Per Request Fees: Charged every time Merchant requests one of the below items Supplies: Billed Per Order N/A Charges for supply orders vary based on the items ordered Dynamic Debit Surcharge Fee N/A Charged for each PIN Debit transaction routed with the Dynamic Routing product PIN Debit Injection Fee $40.00 Charged when merchant elects PIN Debit processing and applies to each device not purchased from CMS. Statement Type Resource Online Statement only Statement Frequency Monthly 4. Card Network Fees – Per Incidence MC Acquiring License Fee * 0.004% Charged on Mastercard Gross Sales volume. See additional information under Card Network Charges section on page 4. MC Digital Enablement / Card Not Present Fee 0.010% Charged on Mastercard Card Not Present Gross Sales volume. AX OptBlue Card Not Present Fee 0.300% Charged on American Express Card Not Present Gross Sales volume. AX OptBlue Application-initiated Fee 0.300% Charged on American Express transactions initiated by a digital wallet application. Discover Network Authorization Fee $0.0190 Charged by Discover on all authorizations for card transactions that are settled through the Discover Network MC Auth Access Fee – AVS Card Present $0.010 Charged by Mastercard when a merchant uses the address verification service to validate a cardholder address MC Auth Access Fee – AVS Card Not Present $0.010 MC Card Validation Code 2 Fee $0.0025 Charged by Mastercard when a merchant submits the Card Validation Code 2 (CVC2) in an authorization request MC SecureCode Transaction Fee $0.030 Charged on MC SecureCode transactions that are sent for verification. MC Account Status Fee (Intra-regional) $0.025 MC Account Status Fee (Inter-regional) $0.03 Visa Zero $ Account Verification Fee Domestic Debit $0.030 Domestic Credit $0.035 International Debit/Credit $0.070 MC Processing Integrity Fee Pre Authorization $0.045 Final Authorization * $0.250* the minimum fee amount for a Final Authorization is $0.04 Visa Misuse of Authorization Fee $0.093 Visa Zero Floor Limit Fee $0.20 Charged when a transaction is deposited but never authorized Visa Transaction Integrity Fee – Credit $0.10 Charged on Visa transactions that do not meet qualification criteria for US Custom Payment Service (CPS) categories. Visa Transaction Integrity Fee – Debit / Prepaid $0.10 Visa System Integrity Fee Domestic $0.10 Data Consistency fees will be charged when certain authorization data elements are changed or manipulated to move from a declined to an approved authorization response. Excessive Authorization fees will be charged for each reattempt in excess of 15 authorizations within a 30-day period. Visa System Integrity Fee Cross Border $0.15 Discover Program Integrity Fee $0.05 Charged on Discover transactions that are downgraded to or directly qualify for US Base-submission interchange program MC Ineligible Chargeback Blocking Fee $3.00 Charged when a fraud related Chargeback is blocked by Mastercard MC Cross Border Assessment Fee 0.60% Visa International Service Assessment Fee 1.00% Charged by MasterCard, Visa, American Express, and Discover on foreign bank issued cards. AX OptBlue International Fee 1.00% Discover International Service Fee 0.80% MC International Support Fee 0.85% Visa Interregional Acquiring Fee 0.45% Discover International Processing Fee 0.50% Visa Partial Auth Non-Participation Fee $0.01 Applies to Petroleum merchants using automated fuel pumps that do not support Partial Authorization MC Global Wholesale Travel Transaction Program B2B Fee 1.57% Applies to Travel merchants for transactions qualifying at the Mastercard Commercial Business-to-Business interchange category. Visa Global B2B Virtual Payment Service Fee 1.55% Applies to Travel merchants for transactions qualifying at the Visa Global B2B Virtual Payments interchange category. MC Humanitarian Program Fee 0.25% Applies to transactions qualifying at the MasterCard Humanitarian Prepaid card interchange category. When this fee applies, other MC Payment Brand fees will be waived. MC Freight Program Fee 0.50% Applies to Freight transactions qualifying at the Freight Program interchange category. 5. Other Fees Fee Description Amount Fee Description Amount Equipment Swap Fees Type Description Fee Refund for Returned Equipment A full refund will be provided on POS Terminals, Tablet Hardware and Tablet Accessories that are returned within ninety (90) days of purchase. Replacement Fee (swap) In warranty POS Terminals, Tablet Hardware and Tablet Accessories 1 $50.00 Replacement Fee (swap) Out of warranty POS Terminals, Tablet Hardware and Tablet Accessories: Replacement (swap) fees vary based on Manufacturer and Model and will fall within the specified range to the right $100 - $1,000 Encryption Fee Safetech $34.95 Late Fee For all equipment returned late, or not returned Up to $1,000 $50.00 swap fee applies to POS Terminals, Tablet Hardware, and Tablet Accessories that are in warranty at the time of the swap; provided that the POS Terminals are compliant with the latest Payment Card Industry standards and supported by CMS. Card Network Charges A significant portion of the fees that Paymentech, LLC, also known as Chase Merchant Services (“CMS”) charges consists of fees and other charges that CMS pays to the various card networks and payment systems (“Card Networks”). These charges (collectively referred to in this Schedule A as “Card Network Fees”, include, but are not limited to, interchange rates, assessments, file transmission fees, access fees, and international and cross border fees, and will be charged to Merchant in addition to the rates set forth above. Whether a particular Card Network Fee applies may be based on a number of factors, such as the type of card or payment method presented, specific information contained within the Transaction, how and when the Transaction is processed, and the merchant’s domicile and industry. Please note that CMS may, from time to time, elect not to charge for certain existing, new or increased Card Network Fees. If CMS elects not to charge any Card Network Fees, CMS reserves the right to begin doing so at any time in the future (including with respect to existing, new or increased Card Network Fees), upon notice to Merchant. No such Card Network Fees will be imposed retroactively. * Mastercard assesses the Mastercard Acquiring License Fee annually to each Acquirer based on the total annual volume of Mastercard-branded sales (excluding Maestro PIN debit volume) of its U.S. domiciled merchants. To fairly distribute the fee across all CMS Mastercard-accepting merchants, a rate of 0.004% will be applied to all of Merchant’s Mastercard gross sales transactions. NOTICE REQUIRED BY AMERICAN EXPRESS: American Express requires that CMS inform Merchants that (i) American Express charges CMS a wholesale discount rate and not interchange and (ii) American Express operates a non-interchange based network. 6. Authorized Signature Authorized Representative Signature: Must appear on Merchant Application Print Name Title x Signature Date Please ensure to initial pages 1, 2 and 3 CONTROL NUMBER: 657310.V3211 Printed: April 29, 2021 Page 4 of 4"
}**

# Schedule A to Merchant Agreement

**J.P.Morgan** **Merchant: City of Lake Worth Beach** **NAPFINSCHEDAICPT2F 202104**

## Assumptions

|  Transaction related assumptions |  | Other assumptions  |
| --- | --- | --- |
|  Payment Transaction Sales Volume | $1,400,000 | Number of locations  |
|  Average Transaction Amount | $49.00 | Authorization / Capture %  |
|  Debit / EBT Transactions | 0 | Chargebacks as % of Sales Transactions  |
|  Conveyed Transactions | N/A | Billing Frequency  |
|  Safetech Encrypted Items | N/A |   |

### Target Qualification Level:

|  Mastercard: Public Sector | MUPS  |
| --- | --- |
|  Visa: CPS Retail 2 (Emerging Markets) | VCR2  |

|  American Express: Emerging Market - Tier 1 | AEM1  |
| --- | --- |
|  Discover: PSL Public Services - Core | D161  |

## 1. Fees applied on every transaction

**Card Network Interchange & any incremental discount rate %** – Mastercard, Visa and Discover assess an Interchange Rate, Assessment Fee and Network Fee for each transaction. American Express assesses a Wholesale Discount Rate and Network Fee for each transaction. These rates and fees will be passed through at cost.

|  Interchange and Wholesale Discount Rates | as set by each Card Network  |
| --- | --- |
|  MasterCard, Visa & Discover Incremental Discount Rate | 0.1500%  |
|  American Express Incremental Discount Rate | 0.1500%  |
|  PIN Debit, PINLess Debit, and/or EBT Network Fees | All standard Debit Network Fees will be assessed  |
|  Debit – Incremental Discount Rate | N/A  |
|  JCB (Japanese Credit Bureau) | N/A  |
|  Voyager Discount Rate (if settled) | N/A  |
|  Wright Express (WEX) Discount Rate (if settled) | N/A  |

|  Card Network Assessments | Card Network Fees | Credit | Debit  |
| --- | --- | --- | --- |
|  Mastercard | $0.0195 | $0.0195 |   |
|  Credit transactions < $1000 and all Debit transactions |  |  |   |
|  Credit transactions > $1000 |  |  |   |
|  Visa | $0.0195 | $0.0155 |   |
|  Debit transactions |  |  |   |
|  Credit transactions |  |  |   |
|  American Express OptBlue Network Fee |  |  |   |
|  Visa Intl Sales Auth (APF) (Charged per Authorization & per Refund) | $0.0395 | $0.0355 |   |
|  Discover |  |  |   |
|  Discover Data Usage Fee | $0.0025 | $0.0025 |   |

|  Card Network Fees |  |  |   |
| --- | --- | --- | --- |
|  MC Connectivity Fee* (per Transaction and Authorization) | $0.0014 | VI Financial Transaction Fee | $0.0018  |
|  MC Reporting & Infrastructure | $0.0003 | VI Reporting & Data Transfer | $0.0002  |

*In some cases, it is not possible to allocate the associated expenses from the payment networks directly to transaction counts or volume, so Chase Merchant Services produces a rate that is based on the associated expense from the payment networks and applies that expense accordingly.

**Customer initials**

**X**

Please initial to acknowledge pg. 1 of the Schedule A pricing sheet

**CONTROL NUMBER:** 657310.V3211

**Printed:** April 29, 2021

**Page 1 of 4**

|  Transaction Fees |   |
| --- | --- |
|  Mastercard per transaction | N/A  |
|  Visa per transaction | N/A  |
|  Discover per transaction | N/A  |
|  JCB per transaction | N/A  |
|  American Express per transaction | N/A  |
|  PIN Debit per transaction | N/A  |
|  PINLess Debit per transaction | N/A  |
|  EBT per transaction | N/A  |
|  Check Verification - Scan per transaction | N/A  |
|  Voyager per transaction | N/A  |
|  Wright Express per transaction | N/A  |
|  Hosted Pay Page per transaction | N/A  |
|  Managed POS Vendor per transaction | N/A  |

|  Authorization Fees |   |
| --- | --- |
|  Mastercard per authorization | $\$ 0.1000$  |
|  Visa per authorization | $\$ 0.1000$  |
|  Discover per authorization | $\$ 0.1000$  |
|  JCB per authorization | N/A  |
|  American Express per authorization | $\$ 0.1000$  |
|  Voyager per authorization | N/A  |
|  Wright Express per authorization | N/A  |
|  Private Label per authorization | N/A  |
|  Dial Backup authorization surcharge | $\$ 0.0100$  |
|  Other Transaction Fees |   |
|  Safetech Encryption per transaction | N/A  |
|  Safetech Tokenization per transaction | N/A  |
|  Level III Purchasing Card per transaction | N/A  |

|  2- One Time and Periodic Fees |  |  |   |
| --- | --- | --- | --- |
|  One Time Fees | Monthly Fees |  | Periodic Fees  |
|  Account Setup Fee | Monthly Service Fee ${ }^{1}$ | $\$ 2.50$ | Annual Fee  |
|  Rush Fee | Monthly Minimum Fee ${ }^{2}$ | $\$ 25.00$ | Card Network Fees  |
|  Terminal Reprogram Fee | Online Reporting Tool | N/A | Visa Fixed Acquirer  |
|  PIN Debit Setup Fee | Safetech Encryption ${ }^{3}$ | N/A | Network Fee ${ }^{4}$  |
|  PIN Pad Encryption Fee | Managed POS Vendor per Terminal | N/A | MC Merchant Location Fee ${ }^{5}$  |
|  Frame Relay: N/A |  |  |   |
|  Setup Fee | N/A | Monthly Fee | N/A  |
|  Third Party Setup Fee | N/A | Third Party Monthly Fee | N/A  |

1 - Monthly service fees will be debited for the first time in the month after Merchant account has been set up. These fees will be debited regardless of whether transactions are processing through the Merchant account. 2 - CMS will apply the Monthly Minimum Fee only when the total amount of all processing fees (Sections 1, 3A, \& 4) is less than $\$ 25.00$. If Merchant's processing fees do not reach $\$ 25.00$, CMS will charge the difference. For example, if processing fees total $\$ 17.00$ CMS would charge an additional $\$ 8.00$ to meet the $\$ 25.00$ minimum. 3 - If Merchant obtains point of sale device(s) from CMS for use with Safetech Encryption, the following additional fees shall be assessed: (a) a onetime fee of $\$ 10.90$ per Verifone device; (b) a one-time fee of $\$ 10.00$ per Ingenico device; and (c) an encryption injection fee of $\$ 34.95$ per device per occurrence. These assessments are in addition to the above Safetech Encryption Fee(s). If Merchant obtains point of sale device(s) from a third party, additional fees may apply. Merchant acknowledges and understands that its use of any fraud mitigation or security enfacement solution (e.g. an encryption product or service), whether provided to merchant by CMS or a third party, in no way limits Merchant's obligation to comply with the Security Standards or Merchant's liabilities set forth in this Agreement. 4 - Visa Fixed Acquirer Network Fee is a monthly fee assessed by Visa based on Merchant Category Code (MCC), dollar volume, number of merchant locations, number of Tax IDs, and whether the physical Visa card is present or not present at the time of the transaction. This fee can vary monthly. 5 - Mastercard Merchant Location Fee of $\$ 1.25$ will be applicable for each month with $\$ 200.00$ or more in Mastercard volume. This fee will be assessed quarterly based on the previous 3 months activity.

|  JPM Payments Platform |  |  |   |
| --- | --- | --- | --- |
|  JPM Payments Platform Transaction Fee | N/A | JPM Payments Platform Monthly Fee | N/A  |
|  JPM Payments Platform Setup Fee | N/A |  |   |

# 3. Per Incidence Fees

3A. Per Incidence Fees: Charged every time the Merchant's account incurs one of the below items

|  Chargeback Fee | $\$ 10.00$ | Charged when a cardholder or card-issuing bank formally protests a charge  |
| --- | --- | --- |
|  Voice Authorization Fee | $\$ 0.65$ | Charged when the Voice Authorization phone number is called to authorize a credit card  |
|  AVS Fee - Electronic | N/A | Charge for each electronic address verification authorization  |
|  Batch Settlement Fee | N/A | Charged for each batch of transaction(s) submitted for settlement  |
|  ACH fee | N/A | Charged for each ACH (transmission of funds) sent to your account  |
|  ACH Return Fee | $\$ 25.00$ | Charged when CMS is unable to debit fees from Merchant's account  |

Customer initials $\quad \mathbf{x}$ Please initial to acknowledge pg. 2 of the Schedule A pricing sheet

|  3B. Per Request Fees: Charged every time Merchant requests one of the below items |  |  |  |   |
| --- | --- | --- | --- | --- |
|  Supplies: | Billed Per Order | N/A | Charges for supply orders vary based on the items ordered |   |
|  Dynamic Debit Surcharge Fee |  | N/A | Charged for each PIN Debit transaction routed with the Dynamic Routing product |   |
|  PIN Debit Injection Fee |  | $\$ 40.00$ | Charged when merchant elects PIN Debit processing and applies to each device not purchased from CMS. |   |
|  Statement Type: | Resource Online |  | Statement only | Statement Frequency: Monthly  |
|  4. Card Network Fees - Per Incidence |  |  |  |   |
|  MC Acquiring License Fee * |  |  | $0.004 \%$ | Charged on Mastercard Gross Sales volume. See additional information under Card Network Charges section on page 4.  |
|  MC Digital Enablement / Card Not Present Fee |  |  | $0.010 \%$ | Charged on Mastercard Card Not Present Gross Sales volume.  |
|  AX OptBlue Card Not Present Fee |  |  | $0.300 \%$ | Charged on American Express Card Not Present Gross Sales volume.  |
|  AX OptBlue Application-initiated Fee |  |  | $0.300 \%$ | Charged on American Express transactions initiated by a digital wallet application.  |
|  Discover Network Authorization Fee |  |  | $\$ 0.0190$ | Charged by Discover on all authorizations for card transactions that are settled through the Discover Network  |
|  MC Auth Access Fee - AVS Card Present |  |  | $\$ 0.010$ | Charged by Mastercard when a merchant uses the address verification service to validate a cardholder address  |
|  MC Auth Access Fee - AVS Card Not Present |  |  | $\$ 0.010$ |   |
|  MC Card Validation Code 2 Fee |  |  | $\$ 0.0025$ | Charged by Mastercard when a merchant submits the Card Validation Code 2 (CVC2) in an authorization request.  |
|  MC SecureCode Transaction Fee |  |  | $\$ 0.030$ | Charged on MC SecureCode transactions that are sent for verification.  |
|  MC Account Status Fee (Intra-regional) |  |  | $\$ 0.025$ | Charged by Mastercard or Visa when a merchant uses this service to do an inquiry that a card number is valid  |
|  MC Account Status Fee (Inter-regional) |  |  | $\$ 0.03$ |   |
|  Visa Zero \$ Account Verification Fee |  |  | $\$ 0.030$ |   |
|  Domestic Debit |  |  | $\$ 0.035$ |   |
|  Domestic Credit |  |  | $\$ 0.035$ |   |
|  International Debit/Credit |  |  | $\$ 0.070$ |   |
|  MC Processing Integrity Fee |  |  | $\$ 0.045$ | Charged when a card is authorized but not deposited and the authorization is not reversed in a timely manner.  |
|  Pre Authorization |  |  | $0.250 \%$ | * the minimum fee amount for a Final Authorization is $\$ 0.04$  |
|  Final Authorization * |  |  | $\$ 0.093$ |   |
|  Visa Misuse of Authorization Fee |  |  | $\$ 0.20$ | Charged when a transaction is deposited but never authorized  |
|  Visa Zero Floor Limit Fee |  |  | $\$ 0.20$ | Charged on Visa transactions that do not meet qualification criteria for US Custom Payment Service (CPS) categories.  |
|  Visa Transaction Integrity Fee - Credit |  |  | $\$ 0.10$ |   |
|  Visa Transaction Integrity Fee - Debit / Prepaid |  |  | $\$ 0.10$ | Data Consistency fees will be charged when certain authorization data elements are changed or manipulated to move from a declined to an approved authorization response.  |
|  Visa System Integrity Fee Domestic |  |  | $\$ 0.10$ | Excessive Authorization fees will be charged for each reattempt in excess of 15 authorizations within a 30-day period.  |
|  Visa System Integrity Fee Cross Border |  |  | $\$ 0.15$ | Charged on Discover transactions that are downgraded to or directly qualify for U.S Base-submission interchange program.  |
|  Discover Program Integrity Fee |  |  | $\$ 0.05$ | Charged when a fraud related Chargeback is blocked by Mastercard.  |
|  MC Ineligible Chargeback Blocking Fee |  |  | $\$ 3.00$ | Charged when a fraud related Chargeback is blocked by Mastercard.  |
|  MC Cross Border Assessment Fee |  |  | $0.60 \%$ | Charged by MasterCard, Visa, American Express, and Discover on foreign bank issued cards.  |
|  Visa International Service Assessment Fee |  |  | $1.00 \%$ |   |
|  AX OptBlue International Fee |  |  | $1.00 \%$ |   |
|  Discover International Service Fee |  |  | $0.80 \%$ |   |
|  MC International Support Fee |  |  | $0.85 \%$ |   |
|  Visa Interregional Acquiring Fee |  |  | $0.45 \%$ | Additional fee charged by MasterCard, Visa and Discover on foreign bank issued cards.  |
|  Discover International Processing Fee |  |  | $0.50 \%$ |   |
|  Visa Partial Auth Non-Participation Fee |  |  | $\$ 0.01$ | Applies to Petroleum merchants using automated fuel pumps that do not support Partial Authorization.  |
|  MC Global Wholesale Travel Transaction Program B2B Fee |  |  | $1.57 \%$ | Applies to Travel merchants for transactions qualifying at the Mastercard Commercial Business-to-Business interchange category.  |
|  Visa Global B2B Virtual Payment Service Fee |  |  | $1.55 \%$ | Applies to Travel merchants for transactions qualifying at the Visa Global B2B Virtual Payments interchange category.  |
|  MC Humanitarian Program Fee |  |  | $0.25 \%$ | Applies to transactions qualifying at the MasterCard Humanitarian Prepaid card interchange category. When this fee applies, other MC Payment Brand fees will be waived.  |
|  MC Freight Program Fee |  |  | $0.50 \%$ | Applies to Freight transactions qualifying at the Freight Program interchange category.  |
|  5. Other Fees |  |  |  |   |
|  Fee Description |  | Amount | Fee Description | Amount  |
|  Customer initials | $x$ |  | Please initial to acknowledge pg. 3 of the Schedule A pricing sheet |   |

|  Equipment Swap Fees | Description | Fee  |
| --- | --- | --- |
|  Refund for Returned Equipment | A full refund will be provided on POS Terminals, Tablet Hardware and Tablet Accessories that are returned within ninety ( 90 ) days of purchase. |   |
|  Replacement Fee (swap) | In warranty POS Terminals, Tablet Hardware and Tablet Accessories ${ }^{1}$ | $\$ 50.00$  |
|  Replacement Fee (swap) | Out of warranty POS Terminals, Tablet Hardware and Tablet Accessories: Replacement (swap) fees vary based on Manufacturer and Model and will fall within the specified range to the right | $\$ 100$ - $\$ 1,000$  |
|  Encryption Fee | Safetech | $\$ 34.95$  |
|  Late Fee | For all equipment returned late, or not returned | Up to $\$ 1,000$  |

${ }^{1} \$ 50.00$ swap fee applies to POS Terminals, Tablet Hardware, and Tablet Accessories that are in warranty at the time of the swap; provided that the POS Terminals are compliant with the latest Payment Card Industry standards and supported by CMS.

# Card Network Charges

A significant portion of the fees that Paymentech, LLC, also known as Chase Merchant Services ("CMS") charges consists of fees and other charges that CMS pays to the various card networks and payment systems ("Card Networks"). These charges (collectively referred to in this Schedule A as "Card Network Fees", include, but are not limited to, interchange rates, assessments, file transmission fees, access fees, and international and cross border fees, and will be charged to Merchant in addition to the rates set forth above. Whether a particular Card Network Fee applies may be based on a number of factors, such as the type of card or payment method presented, specific information contained within the Transaction, how and when the Transaction is processed, and the merchant's domicile and industry.

Please note that CMS may, from time to time, elect not to charge for certain existing, new or increased Card Network Fees. If CMS elects not to charge any Card Network Fees, CMS reserves the right to begin doing so at any time in the future (including with respect to existing, new or increased Card Network Fees), upon notice to Merchant. No such Card Network Fees will be imposed retroactively.

- Mastercard assesses the Mastercard Acquiring License Fee annually to each Acquirer based on the total annual volume of Mastercard-branded sales (excluding Maestro PIN debit volume) of its U.S. domiciled merchants. To fairly distribute the fee across all CMS Mastercard-accepting merchants, a rate of $0.004 \%$ will be applied to all of Merchant's Mastercard gross sales transactions.

NOTICE REQUIRED BY AMERICAN EXPRESS: American Express requires that CMS inform Merchants that (i) American Express charges CMS a wholesale discount rate and not interchange and (ii) American Express operates a non-interchange based network.

## 6. Authorized Signature

Authorized Representative Signature: Must appear on Merchant Application

Print Name

## Signature

## Date

Please ensure to initial pages 1, 2 and 3